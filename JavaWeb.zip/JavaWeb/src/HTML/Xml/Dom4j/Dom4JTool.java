package HTML.Xml.Dom4j;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class Dom4JTool {


    public static  final String PATH="/home/ll/IdeaProjects/JavaWeb/src/HTML/Xml/Dom4j/dom4j1.xml";



    public static Document GetDoucument(String path) throws DocumentException {
        SAXReader reader=new SAXReader();
        Document document=reader.read(path);
        return document;
    }
    public static void XMLWriterTool(Document document) throws IOException {
        OutputFormat outputFormat = OutputFormat.createPrettyPrint();
        XMLWriter xmlWriter = new XMLWriter(new FileOutputStream(Dom4JTool.PATH), outputFormat);
        xmlWriter.write(document);
        xmlWriter.close();
    }

    public static void AddElementSex(Document document, Element root) throws IOException {
        Element p1Node=root.element("p1");
        Element sexNode=p1Node.addElement("sex");
        sexNode.setText("nv");

        Dom4JTool.XMLWriterTool(document);
    }
    public static void AddBeforeAge(Document document,Element root) throws IOException {
        Element p1Node=root.element("p1");
        List<Element> lists=p1Node.elements();
        Element Hobby= DocumentHelper.createElement("Hobby");
        Hobby.setText("run");

//        Element befAge=lists.get(1);
        lists.add(1,Hobby);

        Dom4JTool.XMLWriterTool(document);


    }











}
