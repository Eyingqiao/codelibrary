package HTML.Xml.Dom4j;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;

import java.util.EventListener;
import java.util.List;

public class Dom4jXpathTest {

    /**
     * 需求:获得所有name的属性值,使用XPAth
     *
     *
     *
     * */
    public static void main(String[]arfs) throws DocumentException {
        Document document=Dom4JTool.GetDoucument(Dom4JTool.PATH);

        List<Element> Names=document.selectNodes("//name");
        for(Element name:Names){
            String value=name.getText();

            System.out.println(value);
        }






    }




}
