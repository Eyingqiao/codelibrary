package HTML.Xml.Dom4j;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import javax.sql.rowset.spi.XmlWriter;
import java.io.*;
import java.util.List;

public class AddElementTest {

/**需求,在第一个p1末尾天剑sex标签并设置文本
 * 1解析器
 * 2document
 * 3根节点
 * 获取第一个p1节点:Element p1Node=root.element("p1");
 * 4直接addElement(sex),返回值是Element
 *
 * 5在得到的返回值的element,设置文本值setText();
 * 6!!!回写xml
 * XMLWriter
 *      格式美观:OutputFormat outputFormat=OutputFormat.createPrettyPrint();
 *         XMLWriter xmlWriter= new XMLWriter(new FileOutputStream("路径"),outputFormat);
 *
 *         xmlWriter.write(document);
 *         xmlWriter.close();
 *
 *
 *
 * */







    public static void main(String[]args) throws DocumentException, IOException {
        Document document=Dom4JTool.GetDoucument(Dom4JTool.PATH);
        Element root=document.getRootElement();
//        AddElementSex(document, root);

        Dom4JTool.AddBeforeAge(document,root);

    }





}
