package HTML.Xml.Dom4j;

import org.dom4j.Document;//不要导错包

import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.xml.sax.SAXException;

import javax.sql.rowset.spi.XmlWriter;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.List;


public class TestDom4j {


    /**
     * 需求:获取name属性值
     * 1获取解析器
     * 2获取docuemnt
     * 3获取根节点
     * 4获取指定节点:Elements(),Elements(name):list Element(name):Element
     *
     *
     * */


    public static void main(String[]args) throws ParserConfigurationException, SAXException, DocumentException, IOException {

        Document document=Dom4JTool.GetDoucument(Dom4JTool.PATH);

        Element root=document.getRootElement();

//        SelectNameALL(root);
//        SelectName1(root);
//        SelectNameSecond(root);
//        ModifyAge(document,root);
        GetAttributeValue(root);
    }

    public static void GetAttributeValue(Element root) {
        /**
         * 需求:获取第一个p1的第一个属性id1的值
         *
         *
         * */
            Element P1=root.element("p1");
            String value=P1.attributeValue("id1");
         System.out.println(value);




    }


    public static void ModifyAge(Document document,Element root) throws IOException {
        Element p1=root.element("p1");
        Element ageNode=p1.element("age");
        ageNode.setText("1.5");

        Dom4JTool.XMLWriterTool(document);

    }




    private static void SelectNameSecond(Element root) {
        List<Element> lists=root.elements("p1");
        Element p2=lists.get(1);
        Element name=p2.element("name");
        System.out.println(name.getText());




    }

    private static void SelectName1(Element root) {
        Element p1=root.element("p1");//默认第一个子节点
        Element name1=p1.element("name");
        System.out.println(name1.getText());
    }

    public static void SelectNameALL(Element root) {
        List<Element> lists =root.elements("p1");
        for(Element ele:lists){
            Element Nnode=ele.element("name");
            System.out.println(Nnode.getText());

        }
    }


}
