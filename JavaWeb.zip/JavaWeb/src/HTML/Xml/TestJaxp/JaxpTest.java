package HTML.Xml.TestJaxp;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class JaxpTest {



    public static void main(String[]args) throws Exception {

//        SelectAllName();查询
//        AddNodeAfterP1();//增加
//        modifyNodeContext();//修改内容
//            deleteNode();//删除节点
            ShowAllTags();




    }

    private static void ShowAllTags() throws Exception {

        /**
         * 需求:打印所有节点
         * 1获取根节点:是document
         * 2获取子节点\
         * 3获取子节点的子节点
         *4如果是元素(标签的判断),就打印(因为xml将空格也作为标签,所以必须是元素才能打印,不然#text也打印了)
         *
         * */


        Document document = DocumentBuilderFactory();
        list1(document);
    }

    private static void list1(Node document) {
        if(document.getNodeType()==Document.ELEMENT_NODE){
            System.out.println(document.getNodeName());
        }

        NodeList nodeList=document.getChildNodes();
        for(int i=0;i<nodeList.getLength();i++){
            Node node=nodeList.item(i);
            list1(node);
        }




    }

    private static void deleteNode() throws Exception {


        /**
         * 需求:删除<sex>标签
         *      ////    1DocumentBuilderFactory;
         *      ////    2DocumentBuilder
         *      //    3Docunment(parse)
         *
         *      4获取sex标签节点,
         *      5获取sex父节点,删除子节点sex
         *      6!!!!回写到xml文件中
         *          TransformerFactory
         *          Transformer
         *          Transformer.transform
         *
         *
         * */
        Document document = DocumentBuilderFactory();

        Node SexNOde=document.getElementsByTagName("sex").item(0);
        Node ParentNode=SexNOde.getParentNode();
        ParentNode.removeChild(SexNOde);

        TransformerFactory transformerFactory=TransformerFactory.newInstance();
        Transformer transformer=transformerFactory.newTransformer();
        transformer.transform(new DOMSource(document),new StreamResult("/home/ll/IdeaProjects/JavaWeb/src/HTML/Xml/TestJaxp/xml1.xml"));
    }

    public static Document DocumentBuilderFactory() throws Exception {
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
        return documentBuilder.parse("/home/ll/IdeaProjects/JavaWeb/src/HTML/Xml/TestJaxp/xml1.xml");
    }

    private static void modifyNodeContext() throws Exception {

        /**
         * 需求:修改<sex>标签内容为"nan"
         *      ////    1DocumentBuilderFactory;
         *      ////    2DocumentBuilder
         *      //    3Docunment(parse)
         *      //        4NodeList
         *      5获取p标签第一个节点的sex标签,修改内容
         *
         *      6!!!!回写到xml文件中
         *          TransformerFactory
         *          Transformer
         *          Transformer.transform
         *
         *
         * */

        Document document = DocumentBuilderFactory();
//        Node node=document.getElementsByTagName("p").item(0).getLastChild();
        Node node =document.getElementsByTagName("sex").item(0);
        node.setTextContent("nan");

        TransformerFactory transformerFactory=TransformerFactory.newInstance();
        Transformer transformer=transformerFactory.newTransformer();
        transformer.transform(new DOMSource(document),new StreamResult("/home/ll/IdeaProjects/JavaWeb/src/HTML/Xml/TestJaxp/xml1.xml"));
    }

    private static void AddNodeAfterP1() throws Exception {
        /**
         * 需求:在第一个P标签内末尾添加<sex>标签
         *      ////    1DocumentBuilderFactory;
         *      ////    2DocumentBuilder
         *      //    3Docunment(parse)
         *      //        4NodeList
         *      5获取p标签第一个节点
         *      6创建性别标签sex
         *      7创建文本标签text属性nv
         *      8appendchild
         *      9appendchild
         *      10!!!!回写到小毛驴文件中
         *          TransformerFactory
         *          Transformer
         *          Transformer.transform
         *
         *
         * */
        Document document = DocumentBuilderFactory();
        NodeList nodeList=document.getElementsByTagName("p");
        Node PNode=nodeList.item(0);

        Node sexNode=document.createElement("sex");
        Node textNode=document.createTextNode("nv");
        sexNode.appendChild(textNode);
        PNode.appendChild(sexNode);

        TransformerFactory transformerFactory=TransformerFactory.newInstance();
        Transformer transformer=transformerFactory.newTransformer();
        transformer.transform(new DOMSource(document),new StreamResult("/home/ll/IdeaProjects/JavaWeb/src/HTML/Xml/TestJaxp/xml1.xml"));

    }

    //查询所有名字
    //选择区域,refactor-extract-method-public

    /**
     *
     *
     *
     ////    //jaxp解析器操作xml对象,dom方式解析
     ////    1DocumentBuilderFactory;
     ////    2DocumentBuilder
     //    3Docunment(parse)
     //        4NodeList
     //    5遍历
     //    6获取文本getContextontent()

     *
     * */
    public static void SelectAllName() throws Exception {
        Document document = DocumentBuilderFactory();
        NodeList nodeList=document.getElementsByTagName("name");
        for(int i=0;i<nodeList.getLength();i++){
            Node Name=nodeList.item(i);
            String text=Name.getTextContent();
            System.out.println(text);

        }
    }

}
