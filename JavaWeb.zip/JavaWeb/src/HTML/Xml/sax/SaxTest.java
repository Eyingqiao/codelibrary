package HTML.Xml.sax;

import org.dom4j.datatype.DatatypeElement;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.IOException;

public class SaxTest {
    /**
     *
     *
     * 需求:获取name标签值
     * 1工厂
     * 2实例
     * 3解析,使用parse将流解析为xml
     *
     *
     * */


    public static void main(String[]args) throws ParserConfigurationException, SAXException, IOException {
        SAXParserFactory saxParserFactory=SAXParserFactory.newInstance();
        SAXParser saxParser=saxParserFactory.newSAXParser();
        saxParser.parse("/home/ll/IdeaProjects/JavaWeb/src/HTML/Xml/sax/sax-1.xml",new MyDefaultHander2());







    }
}


class  MyDefaultHander2 extends DefaultHandler{
    /**
     *
     * 获取第一个name标签的值
     *
     * */
    int count=1;
    boolean flag=false;
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if(qName.equals("name")){
            flag=true;
        }

    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {

        if(flag&&count==1){
            System.out.println(new String(ch,start,length));
        }
    }
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(flag){
            flag=false;
            count++;
        }
    }


}




class  MyDefaultHander1 extends DefaultHandler{
/**
 *
 * 获取name标签的值
 *
 * */
    boolean flag=false;
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if(qName.equals("name")){
            flag=true;
        }

    }
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {

        if(flag){
            System.out.println(new String(ch,start,length));
        }
    }
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
       if(qName.equals("name")){
           flag=false;
       }
    }


}






class  MyDefaultHander extends DefaultHandler{

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

        System.out.println("<"+qName+">");
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        System.out.println("</"+qName+">");
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        System.out.println(new String(ch,start,length));
    }
}
