package test.ss.Student; 

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After;
import ss.Student.Student;

/** 
* Student Tester. 
* 
* @author <Authors name> 
* @since <pre>四月 15, 2019</pre> 
* @version 1.0 
*/ 
public class StudentTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: getId() 
* 
*/ 
@Test
public void testGetId() throws Exception {

    Student s1=new Student();
    s1.setId("11");
    System.out.println(s1.getId());
//TODO: Test goes here... 
} 

/** 
* 
* Method: setId(String id) 
* 
*/ 
@Test
public void testSetId() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getName() 
* 
*/ 
@Test
public void testGetName() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: setName(String name) 
* 
*/ 
@Test
public void testSetName() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getAge() 
* 
*/ 
@Test
public void testGetAge() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: setAge(String age) 
* 
*/ 
@Test
public void testSetAge() throws Exception { 
//TODO: Test goes here... 
} 


} 
