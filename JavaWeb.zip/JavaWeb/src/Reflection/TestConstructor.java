package Reflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class TestConstructor {


    public  static void main(String[]args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException, NoSuchFieldException {

        //获取Class字节码文件
        Class clazz=Person.class;
//        Class clazz1=Class.forName("Person");
//        Class clazz2=new Person().getClass();
//
//        testCons1();
//        testCons2();

//        testFiled1();
        testMethod1();


    }

    private static void testMethod1() throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
        Class clazz4=Person.class;
        Person p4=(Person) clazz4.newInstance();

        Method method=clazz4.getDeclaredMethod("setName", String.class);
        method.invoke(p4,"lijianlijian");
        System.out.println(p4.getName());



    }

    private static void testFiled1() throws IllegalAccessException, InstantiationException, NoSuchFieldException {
        Class clazz3=Person.class;
        Person p3=(Person) clazz3.newInstance();
        Field f1=clazz3.getDeclaredField("name");
        f1.setAccessible(true);
        f1.set(p3,"lian1");
        System.out.println(f1.get(p3));




    }

    private static void testCons2() throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Class class1=Class.forName("Reflection.Person");
        Constructor constructor=class1.getConstructor(int.class,String.class);
        Person p2=(Person) constructor.newInstance(22,"lijian");
        System.out.println(p2.getAge()+"    "+p2.getName());

    }

    private static void testCons1() throws IllegalAccessException, InstantiationException {
        Class clazz=Person.class;
        Person p1=(Person) clazz.newInstance();
        p1.setAge(22);
        System.out.println(p1.getAge());



    }
}
