package Enum;

import org.junit.Test;

public class TestEnum3 {

    @Test
    public void test1(){
        //知道对象,得到名称和下标

        Color33 color33=Color33.Green;
        String name=color33.name();
        int index=color33.ordinal();
        System.out.println(name+"   "+index);

    }


    @Test
    public void test2(){
        //知道名字,得到对象
    String name="Yellow";
    Color33 color33=Color33.valueOf(name);
    int index=color33.ordinal();
        System.out.println(index);

    }
    @Test
    public void test3(){

        //知道index,dedaoduixiang
        int index=1;
        Color33[]color33s=Color33.values();
        Color33 color33=color33s[index];
        String name=color33.name();
        System.out.println(name);

    }




}

enum Color33{
    Green,Red,Yellow;


}
