package Enum;

public class TestEnum1 {


    private int color1;
    private  Color2 color2;
    private Color3 color3;
    public void  test(){
        this.color1=Color1.Green;
        this.color2=Color2.Green;
        this.color3=Color3.Yellow;
    }





}
enum Color3{

    Green,Red,Yellow;
}



class Color2{
    private Color2(){
//        构造函数私有化,只能使用提供的三个值,不能再创建实例
    }
    public final static Color2 Green=new Color2();
    public final static Color2 Red=new Color2();
    public final static Color2 Yellow=new Color2();



}
class Color1{

    public final static int Green=1;
    public final static int Red=2;
    public final static int Yellow=3;



}
