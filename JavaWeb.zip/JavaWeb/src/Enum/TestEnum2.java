package Enum;

public class TestEnum2 {


}
enum Color22{
    Green("green"){
        @Override
        public void print() {
            System.out.println("green");
        }
    },Red("red"){
        @Override
        public void print() {
            System.out.println("red");
        }
    },Yellow("yellow"){
        @Override
        public void print() {
            System.out.println("yellow");
        }
    };


    private Color22(String name){}
    public abstract void print();



}