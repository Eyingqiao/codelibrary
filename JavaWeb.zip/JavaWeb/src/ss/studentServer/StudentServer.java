package ss.studentServer;

//import Student.Student;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import ss.Student.Student;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;


public class StudentServer {

    public static void addElement(Student student) throws DocumentException, IOException {
        /**
         * 需求:添加元素
         * 1新建解析器
         * 2获取document
         * 3得到root节点
         * 4root上新建节点,得到Element的返回值.
         * 5节点设置属性值
         * 6回写操作!!!
         *
         *
         *
         * */
        SAXReader reader=new SAXReader();
        Document document=reader.read("StudentSystem/stu.xml");
        Element root=document.getRootElement();

        Element StuNode=root.addElement("stu");
        Element idNode=StuNode.addElement("id");
        Element nameNode=StuNode.addElement("name");
        Element ageNode=StuNode.addElement("age");
        idNode.setText(student.getId());
        nameNode.setText(student.getName());
        ageNode.setText(student.getAge());

        OutputFormat outputFormat=OutputFormat.createPrettyPrint();

        XMLWriter xmlWriter=new XMLWriter(new FileOutputStream("StudentSystem/stu.xml"),outputFormat);
        xmlWriter.write(document);
        xmlWriter.close();
    }
    public static void DelNodeById(String IdValue) throws DocumentException, IOException {

        /**
         * 需求:按照id删除节点
         * 1
         * 2
         * 3
         * 4获取全部的id节点
         * 5判断目标id节点(根据给出的id值)
         * 6使用父节点删除id所在的stu节点

         * */
        SAXReader reader=new SAXReader();
        Document document=reader.read("StudentSystem/stu.xml");
        Element root=document.getRootElement();

       List<Element> StuNodes=root.elements("stu");
        System.out.println(StuNodes.size());

       for(Element stu:StuNodes){
           Element IdNode=stu.element("id");
           if(IdNode.getText().equals(IdValue)){
               System.out.println(IdNode.getText());

               root.remove(stu);

           }

       }

        OutputFormat outputFormat=OutputFormat.createPrettyPrint();
       XMLWriter xmlWriter=new XMLWriter(new FileOutputStream("StudentSystem/stu.xml"),outputFormat);
       xmlWriter.write(document);
       xmlWriter.close();

    }
    public static void DelNodeByIdXpath(String idValue) throws DocumentException, IOException {

    SAXReader reader =new SAXReader();
    Document document=reader.read("StudentSystem/stu.xml");
    Element root=document.getRootElement();
//xpath方法

    List<Element>nodes=root.selectNodes("//id");
    for(Element IdNode:nodes){
        if(IdNode.getText().equals(idValue)){
            Element stuNode=IdNode.getParent();
            Element rootNode=stuNode.getParent();
            rootNode.remove(stuNode);

        }
    }
    //回写操作
            OutputFormat outputFormat=OutputFormat.createPrettyPrint();
        XMLWriter xmlWriter=new XMLWriter(new FileOutputStream("StudentSystem/stu.xml"),outputFormat);
        xmlWriter.write(document);
        xmlWriter.close();

    }
}
