package ss.studentTest;

import org.dom4j.DocumentException;
import ss.studentServer.StudentServer;
//import studentServer.StudentServer;

import java.io.IOException;

public class StudentTest1 {
    public static void main(String[]args) throws IOException, DocumentException {
//        Student student=new Student();
//        student.setId("333");
//        student.setName("lijian");
//        student.setAge("44");

//        StudentServer.addElement(student);
//            StudentServer.DelNodeById("111");
            StudentServer.DelNodeByIdXpath("222");


    }
}
