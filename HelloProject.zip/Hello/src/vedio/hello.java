package vedio;

class Ticket implements Runnable{
    int num=100;
//    Object o=new Object();
    @Override
    public void run() {
        Object o=new Object();
        while(true){
            synchronized (o){


                if(num>0){
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println(Thread.currentThread().getName()+"       "+(num--));
                }
            }
        }
    }
}


public class hello {
    public static void main(String []args){

//        String s=new String("njkdkj");
//        otherapi.out.println(s);
        Ticket t=new Ticket();
        Thread th1=new Thread(t);

        Thread th=new Thread(t);
        Thread th2=new Thread(t);
        Thread th3=new Thread(t);


        th.start();
        th1.start();
        th2.start();
        th3.start();



    }

}
