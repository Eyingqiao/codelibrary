package vedio;



class demo implements  Runnable{
    boolean flag=true;
//    public int num=0;

    @Override
    public void run() {

        while(flag){
            try {
                this.wait();

            } catch (java.lang.IllegalMonitorStateException e) {
                System.out.println(Thread.currentThread().getName()+"    exception");
//                flag=false;

            } catch (InterruptedException e) {
//                e.printStackTrace();
            }
//        }
            System.out.println(Thread.currentThread().getName()+"    try outer ");


        }

    }
    public void setFlag(){

        flag=false;

    }



}

public class ThreadInterrupt {
    public static void main(String []args) {
        demo d = new demo();

        Thread th = new Thread(d);
        Thread th1 = new Thread(d);
        th.start();
        th1.start();

        int num=0;
        for (; ; ) {
            if (++num == 100) {
//                d.setFlag();
//                th.interrupt();
//                th1.interrupt();

                break;

            }
            System.out.println(Thread.currentThread().getName() + "       " + num);

        }
        System.out.println("over");
    }



}
