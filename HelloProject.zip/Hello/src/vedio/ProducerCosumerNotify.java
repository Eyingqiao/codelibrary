package vedio;

import java.util.concurrent.locks.*;
//import java.util.concurrent.locks.ReentrantLock;
//import java.util.concurrent.locks.Condition;
//import java.util.concurrent.locks.ReentrantLock;

class Res{

//    private int num=0;
    boolean flag=false;
    private int count=1;

//    Lock lock = new Lock();
//    Condition c1 =lock.newCondition();

//    Condition

    public  synchronized void set(){
//        while(true){
//    lock.lock();
            while(flag) {
                try {
                    this.wait();
                } catch (InterruptedException e) {
                }
            }
            System.out.println(Thread.currentThread().getName()+"     生产这       "+count);
            count++;
            flag=true;
            this.notifyAll();
    }
//



    public   void get(){
//        while(true){
            while(!flag){
                try {this.wait(); } catch (InterruptedException e) { }
            }

        System.out.println(Thread.currentThread().getName()+"    消费者   "+count);
        flag=false;
        this.notifyAll();

//        }



    }


}




class In implements Runnable{
    Res r=new Res();
    In(Res r){
        this.r=r;
    }

    @Override
    public void run() {
    while (true){
        r.set();
    }


    }
}

class O implements Runnable{
    Res r=new Res();
    O(Res r){
        this.r=r;
    }

    @Override
    public void run() {
        while (true){
            r.get();
        }


    }
}





public class ProducerCosumerNotify {
    public static void main(String []args){
        Res r=new Res();

        In in=new In(r);
        O out=new O(r);

        Thread t0=new Thread(in);

//        Thread t2=new Thread(in);
        Thread t1=new Thread(out);

//        Thread t3=new Thread(out);
        t0.start();
        t1.start();
//        t2.start();
//        t3.start();
//        otherapi.out.println("hldsfhskjf");



    }





}
