package vedio;
/**
 *
 *
 * 当同步与static，stati不可以使用指针，所以用this.getClass或者类名.class
 *
 *
 * */
//class Bank{
//    private int sum;
//
//    public synchronized void add(int num){
//        sum+=num;
//        otherapi.out.println(Thread.currentThread().getName()+"   "+sum);
//    }
//
//
//
//
//
//}
//
//
//
//class Test implements Runnable{
//    private Bank b=new Bank();
////    boolean flag=true;
////    public void show(){
////
////        for (int i=0;i<3;i++){
////            b.add(100);
////        }
////
////    }
//    @Override
//    public void run() {
//        for (int i=0;i<3;i++){
//            b.add(100);
//        }
//    }
//}
//
//


class Sold implements Runnable{
    private static int num=100;
    Object o=new Object();
    boolean flag=true;
    @Override
    public void run() {
//        otherapi.out.println(this);
//        Object o=new Object();
        if(flag) {
            while (true) {

                synchronized (Sold.class) {
                    if (num > 0) {

                        try {
                            Thread.sleep(10);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        System.out.println(Thread.currentThread().getName() + "       " + num--);
                    }

                }
            }
        }else{
            show();

        }


    }
    public static synchronized void show(){
//    otherapi.out.println(this);


        while (true) {

                if (num > 0) {

                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println(Thread.currentThread().getName() + "       " + num--);
                }


        }
    }



}


public class SynFunctionLock {

    public  static void  main(String[]args){

        Sold t=new Sold();
        Thread th=new Thread(t);
        Thread th1=new Thread(t);

//        otherapi.out.println(t);
        th.start();
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        t.flag=false;
        th1.start();




    }




}
