package vedio.winterHoliday;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

public class GenericAdvanceDemo1 {

    public static void main(String []args){
        TreeSet<Student> tt=new TreeSet<Student>(new compareByName());
        tt.add(new Student(11,"Mary"));
        tt.add(new Student(22,"Tom"));
        tt.add(new Student(21,"Mark"));


        Iterator<Student> it=tt.iterator();
        while(it.hasNext()){
            Student temp=it.next();
            System.out.println("temp: Name  "+temp.getName()+"  Age:  "+temp.getAge());


        }

    }


}


class compareByName implements Comparator<Student>{

    @Override
    public int compare(Student o1, Student o2) {
        int result=o1.getName().compareTo(o2.getName());

        return result==0?o1.getAge()-o2.getAge():result;
    }
}

