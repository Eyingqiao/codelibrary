package vedio.winterHoliday;

public class GenericDemo3 {



    public static void main(String []args){


        Tool<String>tt=new Tool<String>();
        tt.setObject("sdfs");
        tt.show(tt.getObject());
        tt.print(new Person(12,"44sf"));
        tt.method(1223);


    }


}
