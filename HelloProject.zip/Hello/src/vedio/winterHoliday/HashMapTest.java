package vedio.winterHoliday;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class HashMapTest {


    public static void main(String args[]){

        HashMap<Integer,String> hm=new HashMap<Integer,String>();
        hm.put(1,"chenhong");
        hm.put(7,"kjfdkjg");
        hm.put(5,"iushdh");
        hm.put(4,"jjkdf");
        Iterator<Map.Entry<Integer,String>> it=hm.entrySet().iterator();
        while(it.hasNext()){

            Map.Entry<Integer,String> temp=it.next();
            Integer key=temp.getKey();
            String value =temp.getValue();
            System.out.println("key:"+key+"  "+"value:"+value);


        }






    }


}
