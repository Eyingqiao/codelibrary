package vedio.winterHoliday;

import java.util.Iterator;
import java.util.TreeSet;

public class GenericDemo1 {








    public static void main(String []args){

        TreeSet<Person> ts=new TreeSet<Person>();
        ts.add(new Person(12,"zhangsan"));
        ts.add(new Person(2,"lisa"));
        ts.add(new Person(12,"zhangsan"));


        Iterator<Person> it=ts.iterator();
        while(it.hasNext()){
            Person temp=it.next();
            System.out.println(temp.getAge()+"      "+temp.getName());


        }


    }
}
