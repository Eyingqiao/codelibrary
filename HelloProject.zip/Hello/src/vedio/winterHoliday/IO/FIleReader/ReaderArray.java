package vedio.winterHoliday.IO.FIleReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReaderArray {


    public static void main(String []args) throws IOException {
        FileReader fr=new FileReader("demo.txt");
        char ch[]=new char[3];
//        int num=fr.read(ch1);
//        otherapi.out.println(num+new String(ch1,0,num));
//        int num1=fr.read(ch1);
//        otherapi.out.println(num1+new String(ch1,0,num1));
//        int num2=fr.read(ch1);
//        otherapi.out.println(num2+new String(ch1,0,num2));
////        int num3=fr.read(ch1);
////        otherapi.out.println(num3+new String(ch1,0,num3));
        int num=0;
        while((num=fr.read(ch))!=-1){
            System.out.println(num+new String(ch,0,num));
        }

    }
}
