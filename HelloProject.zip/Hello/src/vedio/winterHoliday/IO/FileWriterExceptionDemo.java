package vedio.winterHoliday.IO;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class FileWriterExceptionDemo {


    public static void main(String []args){

        Writer fw=null;
        try {
            fw=new FileWriter("write.txt");
            fw.write("df");
        } catch (IOException e) {
            e.printStackTrace();

        }finally {
            if(fw!=null) {
                try {
                    fw.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
        }


    }
}
