package vedio.winterHoliday.IO;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class FileWriterDemo {

    private static final String LINE_SEPRATOR =System.getProperty("line.separator") ;//getProperty()这个方法是获取指定键指示的系统属性

    /**
 * 文件保存位置
 * /home/ll/IdeaProjects/Hello
 *
 * */

    public static void main(String []args) throws IOException {
        /**
         * 构造函数第二个参数为true,续写文件内容,不会覆盖
         *
         * */

        FileWriter fw=new FileWriter("demo.txt",true);
        fw.write("wrw");
        fw.write("aa\rdd"+LINE_SEPRATOR+"xc");

        fw.close();//



    }


}
