package vedio.winterHoliday.ListAndArrays;

import java.util.Arrays;
import java.util.List;

public class ArraysToList {




    public static void main(String []args){

        String []str={"erwe","sdg","dffsd"};
        List<String> list= Arrays.asList(str);
        System.out.println(list);
      boolean b=  list.contains("sdk");
        System.out.println(b);
//        list.add("fdgd");
        Integer []arr={21,32,12,22};
        List< Integer> li=Arrays.asList(arr);
        System.out.println(li);
        System.out.println(li.size());






    }


}
