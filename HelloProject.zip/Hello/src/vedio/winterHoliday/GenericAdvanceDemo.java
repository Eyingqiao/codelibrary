package vedio.winterHoliday;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class GenericAdvanceDemo {


    public static void printEvery(Collection<? extends Person> collection){


        Iterator<? extends Person> it=collection.iterator();

        while(it.hasNext()){

            Person temp=it.next();
            System.out.println("Name:   "+temp.getName()+"   Age:"+temp.getAge());

        }

    }

    public static void main(String[] args) {

        ArrayList<Person> ap = new ArrayList<>();
        ap.add(new Person(12, "p1"));
        ap.add(new Person(20, "p2"));
        ap.add(new Person(18, "p3"));


        ArrayList<Student> as = new ArrayList<>();
        as.add(new Student(12, "s1"));
        as.add(new Student(20, "s2"));
        as.add(new Student(18, "s3"));

        ArrayList<Worker> aw = new ArrayList<>();
        aw.add(new Worker(29, "w1"));
        aw.add(new Worker(21, "w2"));
        aw.add(new Worker(35, "w3"));

        printEvery(ap);
        printEvery(as);
        printEvery(aw);


    }


}
