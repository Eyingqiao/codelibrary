package vedio.winterHoliday;

public class GenericDemo2 {

    public static void main(String []args){


        Tool<Student> tl=new Tool<Student>();
        tl.setObject(new Student(12,"sf"));
//        tl.setObject(new Worker(2,"df"));
        System.out.println(tl.getObject().getAge()+"        "+tl.getObject().getName());
    }
}
