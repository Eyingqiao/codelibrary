package vedio.winterHoliday;

public class GenericDemo4 {


    public static void main(String []args){

        impl1 im=new impl1();
        im.show("wff");
        imple2<Person> im2=new imple2<Person>();
        im2.show(new Person(12,"sgd"));

    }





}

interface Inter<T>{

    public void show(T e);

}

class impl1 implements Inter<String>{


    @Override
    public void show(String e) {
        System.out.println("show:   "+e);
    }
}

class imple2<Q> implements Inter<Q>{


    @Override
    public void show(Q e) {

        System.out.println("class2 Show :"+e);


    }
}

