package vedio.winterHoliday;

import java.io.Serializable;


public class Person implements Comparable<Person>, Serializable {

    private static final long serialVersionUID=132353;
    private int age;//更改属性的修饰符之后，再次运行ObjectinputDemo会出错，因为id发生了变化。
    private  String name;//transient

    public Person(){}


    public Person(int age, String name) {
        this.age = age;
        this.name = name;
    }

    public void show (){
        System.out.println("show method itself");
    }

    public void hahah(String name,int age){


        System.out.println(name+"   "+age);
    }


    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private  void privateMethod(){

        System.out.println("Private method");
    }


    @Override
    public int compareTo(Person o) {
        int result =this.age-o.age;
        return result==0?this.name.compareTo(o.name):result;
//        return 0;
    }
}
