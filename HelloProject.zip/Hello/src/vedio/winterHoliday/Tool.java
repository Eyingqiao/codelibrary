package vedio.winterHoliday;

public class Tool<E> {
    private E object;

    public E getObject() {
        return object;
    }

    public void setObject(E object) {
        this.object = object;
    }

    public  void show(E s){

        System.out.println("show    :"+s);

    }

    public <W> void print(W w){
        System.out.println("print <W>function:  "+w);


    }
    public static <Q>void method(Q e){//静态方法无法识别类定义的范性,使用泛型,直接定义在方法上.

        System.out.println("STATIC function:    "+e);


    }





}
