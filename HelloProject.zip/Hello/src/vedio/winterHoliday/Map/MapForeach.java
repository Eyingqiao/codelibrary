package vedio.winterHoliday.Map;

import java.util.Map;
import java.util.TreeMap;

public class MapForeach {



    public static void  main(String []args){

        Map<Integer,String> map=new TreeMap<>();
        map.put(3,"kongrong");
        map.put(50,"libai");
        map.put(27,"wangyi");


        for(Integer key:map.keySet()){
            String value=map.get(key);

            System.out.println("key :"+key+"    value:  "+value);

        }
        for(Map.Entry<Integer,String> mm:map.entrySet()){
                Integer key=mm.getKey();
                String value=mm.getValue();

            System.out.println("key     "+key+" value:  "+value);


        }


    }
}
