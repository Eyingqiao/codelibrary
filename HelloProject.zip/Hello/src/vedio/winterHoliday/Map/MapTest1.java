package vedio.winterHoliday.Map;

import java.util.Map;
import java.util.TreeMap;
//import java.util.TreeMap;
/*
*
* Map是接口,无法创建实例,用TreeMap并且排序;
* 字符串转字符串数组,已有函数;
* map转字符串也有函数.
*
*
*
* */



public class MapTest1 {


    public static void main(String []args){

        Map<Character,Integer> tm=new TreeMap<Character,Integer>();

        String str="eeeabcabdcdacffff";
        printCount(tm,str);


    }

    public static void printCount(Map<Character,Integer> tm, String str) {
        char[]temp=str.toCharArray();
//        for(int i=0;i<str.length();i++){
//            temp[i]=str.charAt(i);
//
//        }
        for(int i=0;i<str.length();i++){
            int count=1;
            Integer value=tm.get(temp[i]);
            if(value!=null){
                count=value+1;
            }
            tm.put(temp[i],count);

        }
        System.out.println(tm.toString());


    }

}
