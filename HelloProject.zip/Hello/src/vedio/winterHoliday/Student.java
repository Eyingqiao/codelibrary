package vedio.winterHoliday;

public class Student extends  Person{
    public Student(int age, String name) {
        super(age, name);
    }


//    @Override
//    public int getAge() {
//        return super.getAge();
//    }
//
//    @Override
//    public String getName() {
//        return super.getName();
//    }
}
