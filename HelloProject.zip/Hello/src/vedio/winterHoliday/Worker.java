package vedio.winterHoliday;

public class Worker extends Person{


    public Worker(int age, String name) {
        super(age, name);
    }
}
