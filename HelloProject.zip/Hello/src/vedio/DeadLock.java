package vedio;

class lock implements  Runnable{
    private boolean flag;
    public lock(boolean flag){

        this.flag=flag;
    }


    @Override
    public void run() {
        if(flag){

            while(true) {
                synchronized (Lock.locka) {
                    System.out.println(Thread.currentThread().getName() + "           " + "if     locka");
                    synchronized (Lock.lockb) {
                        System.out.println(Thread.currentThread().getName() + "       " + "if    lockb");

                    }

                }
            }


        }else{
            while(true) {
                synchronized (Lock.lockb) {
                    System.out.println(Thread.currentThread().getName() + "           " + "else    lockb");
                    synchronized (Lock.locka) {
                        System.out.println(Thread.currentThread().getName() + "           " + "else     locka");

                    }

                }
            }

        }
    }
}


class Lock{
    public static final Object locka=new Object();
   public static final Object lockb=new Object();


//    public static Object locka;
}

public class DeadLock {


    public static void main(String []args){

        lock a=new lock(true);
        lock b=new lock(false);

        Thread t=new Thread(a);
        Thread t1=new Thread(b);
        t.start();
        t1.start();


    }


}
