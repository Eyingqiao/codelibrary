package vedio.Spring.IO_1.ByteAraryStream;

import java.io.*;

public class ByteArrayStreamDemo {

    public static void main(String[]args) throws IOException {


        ByteArrayInputStream bis=new ByteArrayInputStream("abcdefg".getBytes());

        ByteArrayOutputStream bos=new ByteArrayOutputStream();

        int ch;
        while((ch=bis.read())!=-1){

            bos.write(ch);
        }
        bos.writeTo(new FileOutputStream(new File("byte.txt")));//试用writeTo方法
        System.out.println(bos.toString());


    }
}
