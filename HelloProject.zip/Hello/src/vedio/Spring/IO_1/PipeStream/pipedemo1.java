package vedio.Spring.IO_1.PipeStream;

import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.sql.SQLOutput;

public class pipedemo1 {


    public static void main(String[]args) throws IOException {

        /**
         *
         *
         * 管道输入流应该连接到管道输出流；管道输入流提供要写入管道输出流的所有数据字节。
         * 通常，数据由某个线程从 PipedInputStream 对象读取，并由其他线程将其写入到相应的 PipedOutputStream。
         * 不建议对这两个对象尝试使用单个线程，因为这样可能死锁线程。
         * 管道输入流包含一个缓冲区，可在缓冲区限定的范围内将读操作和写操作分离开。
         */




        test_1();



         }

    private static void test_1() throws IOException {

        PipedInputStream pis=new PipedInputStream();
        PipedOutputStream pos=new PipedOutputStream();

        pis.connect(pos);

        new Thread(new Input(pis)).start();
        new Thread(new Output(pos)).start();


    }

}

class Input implements Runnable{

    private PipedInputStream pi;
    public Input(PipedInputStream pi){
        this.pi=pi;


}
    @Override
    public void run() {

        byte[]bytes=new byte[1024];

        try {
           int len= pi.read(bytes);

            System.out.println(new String(bytes,0,len));

        } catch (IOException e) {

            System.out.println("管道读");
//            e.printStackTrace();
        }


    }
}
class Output implements Runnable{


    private PipedOutputStream po;
    public Output(PipedOutputStream po){
        this.po=po;

    }
    @Override
    public void run() {


        try {
            try {
                Thread.sleep(5000);//如果还没开始写，读的进程就要等待。
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            po.write("abcdefg".getBytes());
        } catch (IOException e) {
//            e.printStackTrace();

            System.out.println("管道写");

        }


    }
}