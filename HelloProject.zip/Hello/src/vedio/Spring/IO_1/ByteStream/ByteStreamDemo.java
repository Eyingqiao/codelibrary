package vedio.Spring.IO_1.ByteStream;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 *
 * 读取字节时，如果要用到数组，要用字节数组，byte.
 * */

public class ByteStreamDemo {


    public static void main(String[] args) throws IOException {

//        test_writer();
        test_read();



    }

    private static void test_read() throws IOException {
        FileInputStream fis=new FileInputStream("demo.txt");

        System.out.println(fis.available());//一次性读取文件长度

        int len=0;
        byte []ch=new byte[1024];
        while((len=fis.read(ch))!=-1){
            System.out.println(new String(ch,0,len));
        }




    }

    private static void test_writer() throws IOException {


        FileOutputStream fos = new FileOutputStream("demo.txt");
        fos.write("fream".getBytes());

        fos.close();


    }
}
