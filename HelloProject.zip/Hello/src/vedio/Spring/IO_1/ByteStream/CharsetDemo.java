package vedio.Spring.IO_1.ByteStream;

import java.io.*;

public class CharsetDemo {

    /***
     *需求：将一段字符串以特定的字符集写入到文本文件中；
     *
     * 1源和目的：outputStream writer
     * 2是否纯文本文本-文件：是纯文本。
     * 3明确设备：硬盘。FileWriter
     *4明确额外功能：是否要高效：是
     *
     */


    public static void main(String[] args) throws IOException {

//        test_1();
        test_read();


    }

    private static void test_1() throws IOException {

        /**
         *
         * 能指定字符集的文件的写入就是FilWriter的父类OutputStreamWriter;
         *
         * 凡是涉及到编码表，一定要转换流。
         *
         *
         * */

        BufferedWriter osw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("charset.txt"), "UTF-8"));

        osw.write("你好");
        osw.close();


    }

    private static void test_read() throws IOException {
        /**
         *
         * 从文本读到控制台；
         * 因为字符集所以转流；
         *
         *
         * */

//        OutputStreamWriter osw=new OutputStreamWriter(new)

        OutputStream out = System.out;



        InputStreamReader isr = new InputStreamReader(new FileInputStream("charset.txt"), "GBK");
        //不同的编码打印出不同数量的汉字

        BufferedReader br = new BufferedReader(isr);
//        int ch;
        char[] ch_1 =new char[1024];
        int len;
        len= br.read(ch_1);
        System.out.println(new String(ch_1,0,len));
        out.close();


    }
}
