package vedio.Spring.IO_1.ByteStream;

import java.io.*;


/**
 *
 * ReadKey的第二种做法，直接利用ReadLine方法可以直接读出一行，但是因为是字符流的方法，所以要先专程字符流。
 *
 * 1字节流转字符流
 * 2字符流关联到BUffered
 *
 * 3Sout是System.out输出流，控制台是字节流，所以要将读到的字符行转成字节流目的地控制台。
 *
 * */

public class Readkey_1 {



    public static void main(String []args) throws IOException {
//        test_1();
        test_2();


    }

    private static void test_2() throws IOException {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));//从键盘字节读到-字符行缓冲区

        BufferedWriter bw=new BufferedWriter(new OutputStreamWriter( System.out));//字符-字节控制台

        String ch;
        while((ch=br.readLine())!=null){
            if(ch.equals("over")){
                break;
            }
//            System.out.println(ch.toUpperCase());

           bw.write(ch.toUpperCase());//字符-字节，将字符行write到控制台目的地
            bw.newLine();
            bw.flush();



        }


    }

    private static void test_1() throws IOException {

        InputStream in =System.in;
        InputStreamReader isr=new InputStreamReader(in);

        BufferedReader br=new BufferedReader(isr);

        String ch;
        while((ch=br.readLine())!=null){
            if(ch.equals("over")){
                break;
            }
            System.out.println(ch.toUpperCase());


        }
    }
}
