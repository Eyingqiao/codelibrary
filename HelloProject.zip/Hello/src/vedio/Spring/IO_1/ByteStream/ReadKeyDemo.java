package vedio.Spring.IO_1.ByteStream;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class ReadKeyDemo {

/**
 *需求：以“over”作为结束标志，将输入转为大写输出。
 * 1键盘以单个字节输入，要判断将字符串成字符串的形式；
 * 2建立StringBuffer对象；
 * 3判断回车符，遇到回车就比较，要么转成大写要么结束。
 *
 * */
    public static void main(String[] args) throws IOException {
//        test_1();
//            test_2();

        test_3();

    }

    private static void test_3() throws IOException {
        InputStream in=System.in;

        InputStreamReader isr=new InputStreamReader(in);//转流


        BufferedReader br=new BufferedReader(isr);//关联，以便使用buffered高效
        String str;
        while ((str=br.readLine())!=null){
            if(str.equals("over")){
                break;
            }
            System.out.println(str.toUpperCase());


        }


    }

    private static void test_2() throws IOException {
        InputStream in=System.in;
        StringBuffer sb=new StringBuffer();
        int ch;
        while((ch=in.read())!=-1){
            if((char)ch=='\n'){

                if (sb.toString().equals("over")){
                    break;
                }
                System.out.println(sb.toString().toUpperCase());
                sb.delete(0,sb.length());

            }else{

                sb.append((char)ch);

            }
        }



    }

    private static void test_1() throws IOException {
        InputStream in = System.in;
        int ch;


        while ((ch = in.read()) != -1) {

            System.out.println(ch);


        }
    }
}
