package vedio.Spring.IO_1.ObjectStream;


import vedio.winterHoliday.Person;

import java.io.*;

/**
 *使对象持久存储在硬盘上，用到序列化技术。
 *序列化（写）和反序列化（读）
 * 1ObjectInputStream中存的对象必须实现serialazation接口,对象序列化。
 *      Seliazatioable用于给序列化的类家id号，用以判断类和对象是否是统一版本。（如果类的属性等发生变化会被检测出来，从而异常）
 *
 * 2默认序列化机制写入的内容，包括对象签名等，不必解析成txt文件等，通常使用。object文件存储。
 *3 private int age;//更改属性的修饰符之后，再次运行ObjectinputDemo会出错，因为id发生了变化。复原照旧
 *3 private int age;//更改属性的修饰符之后，再次运行ObjectinputDemo会出错，因为id发生了变化。复原照旧
 *         //解决方式：    private static final long serialVersionUID=132353;
 *4 transient：非静态数据不想被序列化
 *
 * */

public class ObjectOutputAnInputStreamDemo {

    public static void main(String []agre) throws IOException, ClassNotFoundException {


//        write_1();//序列化
        read_1();// 反序列化




    }


    private static void read_1() throws IOException, ClassNotFoundException {


        ObjectInputStream ois=new ObjectInputStream(new FileInputStream("obj.object"));


        Person p=(Person) ois.readObject();
        System.out.println("age:    "+p.getAge()+"  name: "+p.getName());

        ois.close();



    }

    private static void write_1() throws IOException {


        ObjectOutputStream ois=new ObjectOutputStream(new FileOutputStream("obj.object"));
        ois.writeObject(new Person(22,"张三"));
        ois.close();




    }


}
