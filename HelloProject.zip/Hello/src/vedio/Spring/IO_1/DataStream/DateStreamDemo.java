package vedio.Spring.IO_1.DataStream;

import java.io.*;

import static java.io.DataInputStream.readUTF;

public class DateStreamDemo {
/**
 *
 * 操作基本数据类型
 *  数据输出流允许应用程序以适当方式将基本 Java 数据类型写入输出流中。然后，应用程序可以使用数据输入流将数据读入。
 * */




    public static void main(String[]args) throws IOException {

        //将字符以UTF修改版的形式写入，内容开始会有两个字符用以标识编码的标识；然后读出
        write_1();
        read_1();//读出



    }

    private static void write_1() throws IOException {
        DataOutputStream dos=new DataOutputStream(new FileOutputStream("data.txt"));

        dos.writeUTF("李健");



    }

    private static void read_1() throws IOException {

        DataInputStream dis=new DataInputStream(new FileInputStream(("data.txt")));

       String  UTF=dis.readUTF();
        System.out.println(UTF);

    }
}
