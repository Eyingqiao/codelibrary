package vedio.Spring.IO_1.File;

import java.io.File;
import java.io.FileFilter;

public class FileListDemo {


    public static void main(String []args){
//打印文件夹下所有文件
//        list_demo();
//按后缀筛选文件，按名字过滤
//        list_demo1();


        //list()返回字符串数组，换成listFile（）拿到的是路径名地址，操作更易如反掌，不必按后缀
//        list_demo2();

        //筛选文件，按照属性，这时候要用到实现FileFilter过滤器，而不是filtNameFilter。

        list_demo3();


    }

    private static void list_demo3() {

        /**
         *
         *
         *
         *返回没隐藏的文件
         * */

        File f=new File("/");
        File[]files=f.listFiles(new FileFilterDemo());//用的是listFiles函数，返回值也是FIle路径名
        for(File file:files){

            System.out.println(file);

        }

    }

    private static void list_demo2() {

        File f=new File("/home/ll/IdeaProjects/Hello");
        String []names=f.list(new FIlterByName_1(".txt"));

        for(String name:names){
            System.out.println(name);


        }




    }

    private static void list_demo1() {
        File f=new File("/home/ll/IdeaProjects/Hello");
        String []names=f.list(new FilterByName());

        for(String name:names){
            System.out.println(name);


        }


    }

    private static void list_demo() {

        File f=new File("/");

        String []names=f.list();

        for (String name:names){

            System.out.println(name);
        }


    }
}
