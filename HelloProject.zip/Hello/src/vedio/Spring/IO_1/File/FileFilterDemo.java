package vedio.Spring.IO_1.File;

import java.io.File;
import java.io.FileFilter;

public class FileFilterDemo implements FileFilter {
    @Override
    public boolean accept(File pathname) {
        return !pathname.isHidden();
    }
}
