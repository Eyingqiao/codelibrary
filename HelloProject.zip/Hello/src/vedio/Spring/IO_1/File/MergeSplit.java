package vedio.Spring.IO_1.File;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Properties;

public class MergeSplit {


    private static final int SIZE = 1024;

    public static void main(String[]args) throws IOException {


//        merge();
        File dir=new File("/home/ll/IdeaProjects/Hello/src/vedio");

        merge_1(dir);
    }

    private static void merge_1(File dir) throws IOException {

        /**
         *
         * 需求：1记录配置文件对象，过滤器筛选并获取properties文件
         * 2获取文件信息，load至Properties
         * 3列出碎片信息，通过存储的目录，加过滤器后缀筛选
         * 4判断碎片数量，将碎片在合并记录整合成流。
         *
         * */
        File[]files=dir.listFiles(new filterByPara(".property"));
        if(files.length!=1){
            throw new RuntimeException("文件不止一个，不正确");
        }
        //获取配置文件
        File fp=files[0];
        //加载至属性集合
        Properties pro=new Properties();
        pro.load(new FileInputStream((fp)));
//获取属性
        FileOutputStream fos=new FileOutputStream(fp);
        String fileName=pro.getProperty("filename");
        int count=Integer.parseInt(pro.getProperty("count"));


        //获取碎片文件

        File []files1=dir.listFiles(new filterByPara(".part"));
        //确认数量
        if(files1.length!=count){

            throw new RuntimeException("数量错误");

        }

//        ArrayList
//接下来就是将文件保存至序列流中。





    }


    private static void merge(File dir) throws IOException {
/**
 *
 *
 * 需求：将碎片合并成sequce，然后经融合后的文件重写，也就是重现文件。
 *
 * */

        ArrayList<FileInputStream>arr=new ArrayList<>();
        FileInputStream fis=null;

        FileOutputStream fos=new FileOutputStream(new File(dir,"2.jpg"));
        int count=0;
        for(int i=0;i<2;i++) {

            fis=new FileInputStream(new File(dir,(count++)+".part"));
            arr.add(fis);

        }
        Enumeration<FileInputStream>en= Collections.enumeration(arr);

        SequenceInputStream sis=new SequenceInputStream(en);

        int len;
        byte[]bytes=new byte[SIZE];

        while((len=sis.read(bytes))!=-1){

            fos.write(bytes,0,len);


        }
        fos.close();
        sis.close();


    }

}
