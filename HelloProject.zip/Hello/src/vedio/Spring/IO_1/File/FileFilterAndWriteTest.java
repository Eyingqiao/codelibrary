package vedio.Spring.IO_1.File;

import javax.sound.sampled.Line;
import java.io.*;

public class FileFilterAndWriteTest {
    /**
     * 需求：从指定目录中深度遍历筛选出特定文件，并将结果写入到特定文件中。
     * 指定扩展名列表。
     * 太过混乱。
     */


    public static void main(String[] args) throws IOException {


        File f1 = new File("/home/ll/IdeaProjects/Hello");
//        System.out.println(f1.getAbsolutePath());
        FilenameFilter selector = new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                return name.endsWith(".txt");
            }
        };
//        System.out.println(System.getProperties());
//        System.out.println(System.getProperty("line.seperator"));
        fileterAndWrite_1(f1, selector);
    }

    private static void fileterAndWrite_1(File dir, FilenameFilter selector) throws IOException {
//        FileWriter fw=new FileWriter(dir);
        File ff = new File(dir,"print.txt");

        BufferedWriter fos = new BufferedWriter(new FileWriter(ff));
        File[] files = dir.listFiles();

        for (File file : files) {
//            System.out.println(file);
            if (file.isDirectory()) {
                fileterAndWrite_1(file, selector);

            } else {
                if (selector.accept(dir, file.getName())) {
                                        System.out.println(file.getAbsolutePath());


                }
//                    System.out.println(file);

            }

        }
//        while
            fos.close();

    }

}
