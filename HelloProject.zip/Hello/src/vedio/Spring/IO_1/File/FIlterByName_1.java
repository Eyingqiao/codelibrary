package vedio.Spring.IO_1.File;

import java.io.File;
import java.io.FilenameFilter;

public class FIlterByName_1 implements FilenameFilter {

    private String suffix;

    public  FIlterByName_1(String suffix){
        super();
        this.suffix=suffix;

    }
    @Override
    public boolean accept(File dir, String name) {
        System.out.println(dir+"    "+name);
        return name.endsWith(suffix);
    }
}
