package vedio.Spring.IO_1.File;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Filter;


/**
 * 递归要与写操作分离
 * 递归中不要涉及文件操作，包括new File();否则会在所有子层目录中新建。
 *需求：
 * 从指定目录中深度遍历筛选出特定文件，并将结果写入到特定文件中；
 *
 * 1将目录传参，深度遍历筛选，记录符合的文件
 * 2将集合写入到制定文件中
 * 3选择高效写入，一写一刷新，关闭写入流。
 *
 * */


public class FileFilterAndWriterTest_1 {




    public static void main(String []args) throws IOException {

        File dir=new File("/home/ll/IdeaProjects/Hello");
        FilenameFilter filter=new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                return name.endsWith(".txt");
            }
        };

        List<File>list=new ArrayList<File>();


         FilterDirList(dir, filter,list);





         writeList(dir,list);
    }

    private static void writeList(File dir,List<File>list) throws IOException {
        File file=new File(dir,"write_1.txt");

        BufferedWriter bw=new BufferedWriter(new FileWriter(file));

        if(list.isEmpty()){

            throw new RuntimeException("列表为空");

        }else{
            for(File file1:list){

                bw.write(file1.getAbsolutePath());
                bw.newLine();
                bw.flush();


            }


        }
        bw.close();







    }

    private static void FilterDirList(File dir, FilenameFilter filter,List<File>list) {

            File[]files=dir.listFiles();
            for(File file:files){
                if(file.isDirectory()){
                    FilterDirList(file,filter,list);
                }
                else{

                    if(filter.accept(dir,file.getName())){

                        list.add(file);

                    }

                }

            }


    }









}
