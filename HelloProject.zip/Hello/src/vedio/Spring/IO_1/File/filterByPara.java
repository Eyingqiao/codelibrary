package vedio.Spring.IO_1.File;

import java.io.File;
import java.io.FileFilter;
import java.io.FilenameFilter;

public class filterByPara implements FilenameFilter
{
    String suffix;

    public filterByPara(String suffix){

        this.suffix=suffix;
    }


    @Override
    public boolean accept(File dir, String name) {
        return name.endsWith(suffix);


    }
}
