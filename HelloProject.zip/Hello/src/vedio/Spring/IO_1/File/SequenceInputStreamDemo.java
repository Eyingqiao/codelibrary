package vedio.Spring.IO_1.File;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Vector;

public class SequenceInputStreamDemo {

/***
 *
 *
 * SequenceInputStream 表示其他输入流的逻辑串联。
 * 它从输入流的有序集合开始，并从第一个输入流开始读取，直到到达文件末尾，
 * 接着从第二个输入流读取，依次类推，直到到达包含的最后一个输入流的文件末尾为止。
 */



    public static void main(String[]args) throws IOException {


//       fun_1();
        fun_2();

    }

    private static void fun_2() throws IOException {
        ArrayList<FileInputStream> al=new ArrayList<>();

        for(int i=1;i<4;i++){
            al.add(new FileInputStream(i+".txt"));

        }


        Enumeration<FileInputStream>en= Collections.enumeration(al);
        SequenceInputStream sis=new SequenceInputStream(en);
        FileOutputStream fos=new FileOutputStream("4.txt");
        byte[]bytes=new byte[1024];

        int len;
        while ((len=sis.read(bytes))!=-1){

            fos.write(bytes,0,len);//这个会影响写入正确，如果不表明长度。
        }

        fos.close();
        sis.close();





    }

    private static void fun_1() throws IOException {


        Vector<FileInputStream> vector=new Vector<>();

        FileInputStream i1=new FileInputStream("1.txt");
        FileInputStream i2=new FileInputStream("2.txt");
        FileInputStream i3=new FileInputStream("3.txt");
        FileOutputStream i4=new FileOutputStream("4.txt");
        vector.add(i1);
        vector.add(i2);
        vector.add(i3);
        Enumeration<FileInputStream> en=vector.elements();//vector-Enum-1



        SequenceInputStream sis=new SequenceInputStream(en);

        byte[]bytes=new byte[1024];//是Byte，不是Byte。

        int line;
        while((line=sis.read(bytes))!=-1){
            i4.write(bytes,0,line);

        }
        i4.close();
        sis.close();



    }
}
