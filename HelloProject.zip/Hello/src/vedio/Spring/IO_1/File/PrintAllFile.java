package vedio.Spring.IO_1.File;

import java.io.File;

public class PrintAllFile {
/**
 *
 * 深度遍历
 *
 * */


    public  static void main(String []args){

        int count=0;
        ListAll_1(new File("//home/ll/IdeaProjects/Hello"),count);//home/ll/IdeaProjects/Hello/src



    }

    private static void ListAll_1(File f1,int count) {

        System.out.println(f1.getAbsolutePath());
//        File f1=new File("/");
        File []files=f1.listFiles();
        count++;
        for(File file:files){
            if(file.isDirectory()){
                ListAll_1(file,count);

            }else {
                System.out.println(getSpace(count) + file.getAbsolutePath());
            }

        }

    }

    private static String getSpace(int count) {
    StringBuffer sb=new StringBuffer();
        for(int i=0;i<count;i++){

            sb.append(" ");
        }


        return sb.toString();


    }
}
