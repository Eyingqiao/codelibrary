package vedio.Spring.IO_1.File;

import java.io.*;

/**
 *
 * PrintStream的Print方法
 * printStream 为其他输出流添加了功能，使它们能够方便地打印各种数据值表示形式。
 * 它还提供其他两项功能。与其他输出流不同，PrintStream 永远不会抛出 IOException；
 * print能保持数据的表现格式，但是无法保证数据长度print（97）两个字节原样输出，write（610）作为一个字节。
 *
 * */


public class PrintStream {




    public static void main(String[]args) throws IOException {

        PrintWriter pw=new PrintWriter(System.out,true);
        pw.write(620);//只保留最低8位，扔掉24位。
        pw.print(97);//97
        pw.write(97);//a
        pw.close();


//        PrintWriterDemo();


    }

    private static void PrintWriterDemo() throws IOException {

//        PrintWriter pw=new Pri
//        BufferedInputStream bis=new BufferedInputStream(System.in);
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

        PrintWriter pw=new PrintWriter(new FileWriter("printStream.txt"),true);
        String line;
        while((line=br.readLine())!=null){
                pw.println(line.toUpperCase());
//                pw.flush();

        }
        br.close();
        pw.close();




    }
}
