package vedio.Spring.IO_1.File;

import java.io.File;

public class DeleteAllFile {


/**
 *
 *
 * 递归删除目录
 * */
    public static void main(String[]args){
//        test_1();


        File f=new File("a");
//        System.out.println(f.getAbsolutePath());
        DeleteDictory(f);

    }

    private static void DeleteDictory(File dir) {

        File []files=dir.listFiles();
        for(File file:files){

            if(file.isDirectory()){
                DeleteDictory(file);

            }else {
                System.out.println(file.getName() + ":    " + file.delete());

            }
        }
        System.out.println(dir.getName()+":    "+dir.delete());


    }

    private static void test_1() {

        File f2=new File("a"+File.separator+"b"+File.separator+"c");
//        File ff=new File("zxcvx");
        boolean b=f2.mkdirs();
        System.out.println(b);


    }
}
