package vedio.Spring.IO_1.File;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;


/**
 *1获取
 *  1.txt.1名字
     *  路径
     *  大小
     *  最后修改时间
 *  2 创建和删除
 *  3判断
 *  4重命名
 *  5listRoot
 *
 *
 * */

public class FileMethoddemo {

    public static void main(String []args) throws IOException {



//        File f=new File("C"+File.separator);//separator是/
        createAndDelete();
//        getFileProperty();
//        isDemo();
//            ChangeName();

//        listRootDemo();

//        listSpace();
    }

    private static void listSpace() {
        File f=new File("/home/ll");
        System.out.println("getFreeSpace:   "+f.getFreeSpace());


        System.out.println("getUsableSpace: "+f.getUsableSpace());

        System.out.println("getTotalSpace:  "+f.getTotalSpace());

    }


    private static void listRootDemo() {
        File []files=File.listRoots();

//        System.out.println(files);
        System.out.println(files.length);
        for(File file:files){

            System.out.println(file);
        }


    }

    private static void ChangeName() {

        /**
         *
         * 重命名的同时可以实现位置移动。
         *
         * */

        File f1=new File("7.txt");
//        File f2=new File("7.txt");
        File f3=new File("/home/ll/IdeaProjects/aa.txt");

        boolean b=f1.renameTo(f3);
        System.out.println(b);
//        System.out.println(f1.getAbsolutePath());


    }

    private static void isDemo() throws IOException {

        File f=new File("2.txt");//流不会被覆盖的问题

//        f.createNewFile();
        System.out.println(f.exists());//先判断是否存在，再判断类型
//        f.mkdir();
        System.out.println(f.isDirectory());
        System.out.println(f.isFile());

    }

    private static void getFileProperty() {

        File f=new File("demo.txt");//pathSeparator是：
//        System.out.println(f);

        String name= f.getName();
        String path=f.getPath();
        String abPath=f.getAbsolutePath();
        long len=f.getFreeSpace();
        long time=f.lastModified();

        Date date=new Date(time);

        DateFormat df=DateFormat.getDateTimeInstance(DateFormat.LONG,DateFormat.LONG);

        String t1=df.format(date);

        System.out.println("name:   "+name);
        System.out.println("path:   "+path);
        System.out.println("abPath:   "+abPath);
        System.out.println("len:   "+len);
        System.out.println("time:   "+t1);




    }

    private static void createAndDelete() throws IOException {


        /**
         * 文件的创建删除
         *
         * */
//        File f1=new File("t1.txt");
//
//       boolean b1= f1.createNewFile();//如果已经创建了不会覆盖，且返回false；
//        //当且仅当不存在具有此抽象路径名指定名称的文件时，不可分地创建一个新的空文件。
//        System.out.println(b1);
//        boolean d1=f1.delete();
//
//        System.out.println(d1);


        /**
         * 目录的创建删除
         *
         * */


        File f2=new File("dffg"+File.separator+"xf");//创建深层文件夹目录，分隔符用seperator（）

//        System.out.println(f2.delete());//目录的删除只能删掉最深层的文件夹，而不会把整个目录删掉。


        boolean m1=f2.mkdirs();//建立深层目录
        System.out.println(m1);
        System.out.println(f2.getAbsolutePath());
        System.out.println(m1);
//        System.out.println(f2.delete());
//        System.out.println(f2.getAbsolutePath());




    }






}
