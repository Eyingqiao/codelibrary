package vedio.Spring.IO_1.File;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

/**
 * 需求：应用程序开启五次之后，提示注册，并不允许开启；
 *
 * 1建立计数器，还能够持久存储，不会因为每次启动而消失；
 * 2建立配置文件，从中读取启动次数，并加1，判断次数是否到达；
 *      每次判断是否需要新建文件；
 *      读取原数据，如果数据为空新建键值对，并写入，
 *      如果不空读出，累加；
 *      判断次数，及时退出虚拟机，而不是成员函数。
 *      数据重新写入。
 * 3文件中存储要以键值对形势，便于识别，而且持久存储是在硬盘文件中，要操作流，所以map+io=properties；
 *
 *
 *
 * */

public class AppLoginCount {


    public static void main(String[]ags) throws IOException {

        countDemo();

    }

    private static void countDemo() throws IOException {
        File log=new File("count.properties");

        if(!log.exists()){
            log.createNewFile();
        }
        int count=0;

        Properties p1=new Properties();
        FileReader fr=new FileReader(log);

        p1.load(fr);
        String num=p1.getProperty("time");


        if(num!=null) {

            count=Integer.parseInt(num);
            if(count==5){

                throw  new RuntimeException("请注册，充钱");

            }
        }
        count++;
        p1.setProperty("time",Integer.toString(count));

        FileWriter fw=new FileWriter(log);
        p1.store(fw,"");
        fw.close();
        fr.close();






    }


}
