package vedio.Spring.IO_1.File;

import java.io.File;
import java.io.FileFilter;
import java.io.FilenameFilter;
import java.util.logging.Filter;

/**
 *需求：过滤
 *
 *
 * */

public class FilterByName implements FilenameFilter {



    @Override
    public boolean accept(File dir, String name) {


        System.out.println(dir+"    :"+name);
        return name.endsWith(".java");
    }
}
