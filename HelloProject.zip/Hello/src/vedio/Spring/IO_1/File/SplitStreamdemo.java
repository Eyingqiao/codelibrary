package vedio.Spring.IO_1.File;

import java.io.*;
import java.util.Properties;

public class SplitStreamdemo {


    private static final int SIZE =25*1024 ;//以25kB为单位进行分割。

    public static void main(String[]args) throws IOException {
/**
 *
 * 需求：1file切成3两个
 * 2 将源文件以及切割的情况存储到配置文件。
 *
 * */

        File file=new File("1.jpg");
        split_1AndRecord(file);
        }


    private static void split_1AndRecord(File file) throws IOException {


        //切成碎片
        File dir=new File("/home/ll/IdeaProjects/Hello/src/vedio");
        FileInputStream fis=new FileInputStream(file);

        byte[]bytes=new byte[SIZE];
        int len;
        int count=0;
        FileOutputStream fos=null;
        while ((len=fis.read(bytes))!=-1){

            fos=new FileOutputStream(new File(dir,(count++)+".part"));
            fos.write(bytes,0,len);
            fos.close();//可以这样关闭，不会出错。

        }

        //写到配置文件所需的配置文件流
        FileOutputStream fos2=new FileOutputStream(new File(dir,count+".property"));

        //采集属性所需要的键值对。
        Properties pro=new Properties();
        pro.setProperty("filename",file.getName());

        pro.setProperty("splitNum",""+count);

        pro.store(fos2,"split to some");










    }
}
