package vedio.Spring.IO_1.File;

import java.io.*;
import java.util.Properties;
import java.util.Set;


/**集合中的数据可以来自于流中，也可以保存到流中。
 *
 *
 * 1properties除Map的独特方法；
 * 2prperties的list方法，结合输出流，打印到具体输出位置；比如控制台；
 * 3配置文件的打印
 * 4持久存储方法：store，字符流字节流皆可。
 * 5load,集合数据来源于流。
 * 6 模拟load
 * 7修改配置文件,filReader和FileWriter针对同一文件流关联的语句不能放在一起，因为FIleWriter会直接覆盖文件流，让文件空白。
 *  所以要先将文件加载到集合中，并修改内容，之后重新写入到空白中。
 *
 * */
public class Map_PropertiesDemo {


    public static void main(String[]args) throws IOException {

//        print_1();

//        print_2();

//        print_3();


//        store_1();

//        load_1();
//        simulate_load();

        modify_7();


    }

    private static void modify_7() throws IOException {
        File f7=new File("store.txt");
        FileReader fr=new FileReader(f7);
        Properties p7=new Properties();

        p7.load(fr);
        p7.setProperty("aaa","haha");
        p7.list(System.out);

        FileWriter fw=new FileWriter(f7);

        p7.store(fw,"");

        fr.close();
        fw.close();






    }

    private static void simulate_load() throws IOException {
        Properties p5=new Properties();

        BufferedReader br=new BufferedReader(new FileReader("store.txt"));
        String line;

        while ((line=br.readLine())!=null){
            if(line.startsWith("#")){
                continue;
            }
            String []rd=line.split("=");

//            System.out.println(rd[0]+"::"+rd[1.txt]);
            p5.setProperty(rd[0],rd[1]);

        }
        p5.list(System.out);





    }

    private static void load_1() throws IOException {
        Properties p4=new Properties();


        BufferedReader br=new BufferedReader(new FileReader("store.txt"));


        p4.load(br);
//        System.out.println();

        p4.list(System.out);




    }

    private static void store_1() throws IOException {


        Properties properties1=new Properties();
        properties1.setProperty("gggg","boss");

        properties1.setProperty("df","profe");
        properties1.setProperty("r","history");
        properties1.setProperty("aaa","hehe");

        FileWriter fw=new FileWriter("store.txt");

        properties1.store(fw,"storeproperties");

    }

    private static void print_3() {



        Properties pro=System.getProperties();

//        pro.list(System.out);
        System.out.println(System.getProperty("file.encoding"));
    }

    private static void print_2() {



        Properties properties1=new Properties();
        properties1.setProperty("gggg","boss");

        properties1.setProperty("df","profe");
        properties1.setProperty("r","history");
        properties1.setProperty("aaa","hehe");


        properties1.list(System.out);


    }

    private static void print_1() {


        Properties properties=new Properties();
        properties.setProperty("wangwu","boss");

        properties.setProperty("hejie","profe");
        properties.setProperty("lijian","history");
        properties.setProperty("wangjian","hehe");

        Set<String> ps=properties.stringPropertyNames();

        for(String s:ps){
            String value=properties.getProperty(s);

            System.out.println("key:    "+s+"value:  "+value);



        }

    }
}
