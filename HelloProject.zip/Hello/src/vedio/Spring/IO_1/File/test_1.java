package vedio.Spring.IO_1.File;

import java.io.*;

public class test_1 {


    public static void main(String[]args) throws IOException {


        String a = "名";
        System.out.println("UTF-8编码长度:"+a.getBytes("UTF-8").length);
    }
}
