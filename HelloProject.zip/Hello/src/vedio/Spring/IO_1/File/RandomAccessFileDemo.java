package vedio.Spring.IO_1.File;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomAccessFileDemo {

    /**随机访问的特点（能定位操作，有指针）
     * 1既能读也能写，通过模式“rw"或者”r"设置，不是FIle类，父类是Object
     * 2内部维护一个byte数组有指针可以操作
     * 3可以通过getFilePointer获取指针，和seek方法修改指针
     * 4该对象其实就是对字节输出流和字节输入流进行了封装
     * 5该对象的源和目的都只能是文件（String路径或者FIle），从构造函数可以看出。
     *6文件不存在创建，文件存在就不创建
     *7指针的获取和设置,尽量不要字符串和数字混读，大小不一样，一个是3为单位一个是4个字节为单位。
     *8可以用于多线程同时写，使用指针选择不同的位置，同时开始。
     * */

    public static void main(String[]args) throws IOException {

//        RandomAccessFile_write();
        RandomAccessFile_read();


    }

    private static void RandomAccessFile_read() throws IOException {



        RandomAccessFile readrsf=new RandomAccessFile("raf.txt","r");

// 设置指针
        readrsf.seek(3*4);

        int re=0;

        re=readrsf.readInt();

        System.out.println("int:   "+re);
        System.out.println(readrsf.getFilePointer());
        readrsf.close();


    }

    private static void RandomAccessFile_write() throws IOException {

        RandomAccessFile raf=new RandomAccessFile("raf.txt","rw");

raf.seek(3*4);
raf.writeInt(444);

//        raf.writeInt(1000);
//
//        raf.writeInt(100);//不支持1个字节之外的数据，而且一个汉字3个字节

        raf.close();





    }

}
