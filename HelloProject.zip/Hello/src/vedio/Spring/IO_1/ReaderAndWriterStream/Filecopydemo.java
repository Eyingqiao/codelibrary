package vedio.Spring.IO_1.ReaderAndWriterStream;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Filecopydemo {


    public static void main(String []args) throws IOException {
        FileReader fr=new FileReader("demo.txt");

        FileWriter fw=new FileWriter("copy.txt",true);
//        copy(fr,fw);
        copy_1(fr,fw);




    }
    /**
     * 两种写的方式
     * 1用数组
     * 2不用数组
     *
     * */

    private static void copy_1(FileReader fr, FileWriter fw) throws IOException {
        int len=0;
//        char[]ch=new char[1024];
        while((len=fr.read())!=-1){
            fw.write(len);

        }
        fw.close();
        fr.close();




    }

    private static void copy(FileReader fr, FileWriter fw) throws IOException {
        int len=0;
        char[]ch=new char[1024];
        while((len=fr.read(ch))!=-1){
            fw.write(ch);//ch,0,len也可以


        }

        fw.close();
        fr.close();

    }

}
