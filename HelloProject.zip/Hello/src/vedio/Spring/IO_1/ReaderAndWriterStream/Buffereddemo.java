package vedio.Spring.IO_1.ReaderAndWriterStream;

import java.io.*;

public class Buffereddemo {

    /**
     * bufferedReaader和 __Writer是为了更高效的
     *
     * readLine()方法其实是判断换行符,从而实现读一行.
     *bufferedReader的read()方法其实是覆盖了父类的read()方法.直接从缓冲区中读?
     *
     * */


    public static void main(String []args) throws IOException {

        test();
//        test_1();

    }

    private static void test_1() throws IOException {
        FileWriter fw=new FileWriter("copy.txt");

        BufferedWriter bw=new BufferedWriter(fw);
        bw.write("jheh");
        bw.newLine();
        bw.write("haha");

        bw.close();






    }

    private static void test() throws IOException {
        FileReader fr=new FileReader("demo.txt");
        MyBufferedReader br=new MyBufferedReader(fr);//使用自己写的缓冲区类
//        BufferedReader br=new BufferedReader(fr);


        /**
         *
         * 原来的方式和自己写的是一样的效果
         *
         * */

//        String str=null;
//        String str =br.readLine();
//        while(str!=null){
//
//            System.out.println(str);
//            str=br.readLine();
//
//
//        }
//
//        br.readLine();


        String str =br.myReadLine();
        while(str!=null){

            System.out.println(str);
            str=br.myReadLine();


        }


    }
}
