package vedio.Spring.IO_1.ReaderAndWriterStream;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;


/**
 *
 *LineNumberReader是装饰类BufferedReader的子类;
 */


public class LineNumberReaderDemo {



    public  static void main(String []args) throws IOException {


        test();


    }

    private static void test() throws IOException {

        FileReader fr=new FileReader("demo.txt");

        LineNumberReader lr=new LineNumberReader(fr);

        String str;
        lr.setLineNumber(10);//设置开始计数行号
        while((str=lr.readLine())!=null){

            System.out.println(lr.getLineNumber()+":    "+str);


        }



    }


}
