package vedio.Spring.IO_1.ReaderAndWriterStream;

import java.io.*;
import java.nio.Buffer;

public class BufferedCoptDemo {


    public  static void main(String []args) throws IOException {


//        test();

            test_1();


    }

    private static void test_1() throws IOException {
        FileReader fr_1=new FileReader("demo.txt");

        BufferedReader br_1=new BufferedReader(fr_1);

        FileWriter fw_1=new FileWriter("copy_buf.txt",true);
        BufferedWriter bw_1=new BufferedWriter(fw_1);

        String str;
        while((str=br_1.readLine())!=null){
                bw_1.write(str);
                bw_1.newLine();//手动加回车换行

        }
        bw_1.close();
        br_1.close();


    }

    private static void test() throws IOException {

        FileReader fr=new FileReader("demo.txt");

        BufferedReader br=new BufferedReader(fr);

        FileWriter fw=new FileWriter("copy_buf.txt",true);
        BufferedWriter bw=new BufferedWriter(fw);

        int len=0;
        while((len=br.read())!=-1){
            bw.write(len);

        }

        bw.close();



    }
}
