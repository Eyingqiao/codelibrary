package vedio.Spring.IO_1.ReaderAndWriterStream;

import java.io.FileReader;
import java.io.IOException;

/**
 * 写出高效的BufferedReader的Read()和ReadLine()方法;
 *
 * Read方法的原理就是从内存中读一部分到给定的数组,判断是否从内存中缓存的部分读完,或者内存中也没有了
 * ReadLine就是判断换行符,然后遇到就输出.
 *
 * */


public class MyBufferedReader {//extends Reader完整的装饰类

    private FileReader fr;//Reader作为增强的对象,FIleReader太局限

    public MyBufferedReader(FileReader fr) throws IOException {//参数要改成Reader
        this.fr=fr;
    }

//    public  void SimulationBufferedReaderDemo(FileReader fr){
//        this.fr=fr;
//
//    }
    private char buffer[];
    private int pos=0;
    private int count=0;

    public  int myRead() throws IOException {
//        int ch;
        if(count==0){//缓存的读完了
            count=fr.read();
            pos=0;

        }
        if(count<0){//内存中(文件内容)也没有了
            return -1;
        }
        int ch=buffer[pos];
        pos++;
        count--;


//        char ch;
        return ch;



    }

    public String myReadLine() throws IOException {

        StringBuffer sb = new StringBuffer();

        int ch = 0;
        while ((ch = fr.read()) != -1) {

            if ((char) ch == '\r') {
                continue;
            }
            if ((char) ch == '\n') {
                return sb.toString();
            }

            sb.append((char) ch);

        }
        if (sb.length() != 0) {

            return sb.toString();
        }
        return null;

    }
    public void close() throws IOException {
        fr.close();

    }

}


