package vedio.Spring.IO_1.CharsetTable;

import java.io.UnsupportedEncodingException;

public class Codedemo {


    public static void main(String[]args) throws UnsupportedEncodingException {


//编码：看得懂-看不懂：String-byte
//       code_1();



        String str="你好";// UTF-8"码表的你好：-28-67-96-27-91-67
        byte[]bytes=str.getBytes();
       //解码
        code_2(bytes);


    }

    private static void code_2(byte[] bytes) throws UnsupportedEncodingException {

        String code=new String(bytes,"UTF-8");//String的构造方法构造符合要求的String对象
        System.out.println(code);


    }

    private static void code_1() throws UnsupportedEncodingException {



        String str="你好";// UTF-8"码表的你好：-28-67-96-27-91-67
        byte[]bytes=str.getBytes("UTF-8");
        for(byte bt:bytes){

            System.out.print(bt);
        }



    }
}
