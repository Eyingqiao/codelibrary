package vedio.Spring.IO_1.CharsetTable;

import java.io.UnsupportedEncodingException;

public class ReadCompletedCHinese {

    /**
     *
     * 需求：读出完整汉字，读到半个汉字就舍弃
     * 以GBK编码为标准：一个汉字两个字节
     * 1判断编码后负数的个数，从要截取的长度开始计算，到正数暂停，偶数就输出，奇数就前移一位后输出。
     *2返回字符串并打印时，也要规定字符编码形式，将字符创设置正确编码，和之前编码要一致，不然就按GBK编码，UTF解码输出
     *3UTF三个字节；
     * */
    public static void main(String[]ag) throws UnsupportedEncodingException {



        //琲琲较为特殊，GBK值6一负一正。
        String str=new String("你好ab李健cd琲琲");

        byte[]bytes=str.getBytes("GBK");
        byte[]bytes1=str.getBytes("UTF-8");

//        int length=bytes.length;
//        for(int i=0;i<length;i++){
//
//            System.out.println("截取后的数据: "+cutBylength(bytes,i+1));
//        }


        //GBK三字节计算

        int length1=bytes1.length;



        for(int i=0;i<length1;i++){

            System.out.println("截取后的数据: "+cutBylength_1(bytes1,i+1));
        }

//        cutBylength_1(bytes1,length1);




    }

    private static String cutBylength_1(byte[] bytes1,int length1) throws UnsupportedEncodingException {

        int count1=0;
        for(int i=length1-1;i>=0;i--){
            if(bytes1[i]<0){
                count1++;
            }
            else{
                break;
            }

        }
        if(count1%3==0){
            return new String(bytes1,0,length1,"UTF-8");
        }
        else if(count1%3==1){
            return new String(bytes1,0,length1-1,"UTF-8");
        }else{

            return new String(bytes1,0,length1-2,"UTF-8");

        }





    }

    private static String cutBylength(byte[]bytes,int length) throws UnsupportedEncodingException {
        int count=0;
        for(int i=length-1;i>=0;i--){
            if(bytes[i]<0){
                count++;
            }
            else{
                break;
            }

        }
        if(count%2==0){
            return new String(bytes,0,length,"GBK");
        }
        else {
            return new String(bytes,0,length-1,"GBK");
        }


//return new String("sd");


    }


}
