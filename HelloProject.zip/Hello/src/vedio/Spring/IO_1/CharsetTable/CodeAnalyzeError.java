package vedio.Spring.IO_1.CharsetTable;

import java.io.UnsupportedEncodingException;

public class CodeAnalyzeError {


   /**
    *
    * 编码因为用错编码表解析，而出现的解析错误，或许可以拯救,仅仅是可能，不代表所有的都可以
    *
    * 不可以的情况：例如“你好”gbk->utf-8 utf-8->gbk，将该板块形成的byte数组-60 -88 -88 -77
    * ，也就是字符序列拿到utf8是无解，所以翻译成？？，而？？是有编码的是-17 -54 -88 -17 -54 -88 -17 -54 -88
    * 从而解析后也是错的，而且字符串的数量也对不上，由“你好”->到4,5个字
    * 方式就是将结果再一次按照错的编码表编码，重新解出来。
    *
    * */
   public static void main(String[]args) throws UnsupportedEncodingException {


       String str="李健";
       byte[]bytes=str.getBytes("UTF-8");
       String result=new String(bytes,"ISO8859-1");
       System.out.println(result);

       solve(result);

   }

    private static void solve(String result) throws UnsupportedEncodingException {
        byte[]bb=result.getBytes("ISO8859-1");
        String finalR=new String(bb,"UTF-8");
        System.out.println(finalR);



    }


}
