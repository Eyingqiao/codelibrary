package vedio.Spring.Reflection;

import vedio.winterHoliday.Person;

import java.io.ObjectInput;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class ReflectPerson {

//    Person p=new Person();
    /**
     *
     * 获取Person对象的三种方式
     *获取字节码文件对象
     *
     * */

    public static void main(String[]args) throws IllegalAccessException, InstantiationException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException {


//      method_1();

//        method_2();

        method_3();


    }

    private static void method_3() throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {

        String path="vedio.winterHoliday.Person";
        Class clazz=Class.forName(path);

        Constructor constructor=clazz.getConstructor(String.class,int.class);

        Object  p=constructor.newInstance("wang",18);








    }

    private static void method_2() throws ClassNotFoundException, IllegalAccessException, InstantiationException {

        String path="vedio.winterHoliday.Person";
        Class clazz=Class.forName(path);
        Object cp=clazz.newInstance();
        System.out.println();




    }

    private static void method_1() {
        vedio.winterHoliday.Person p=new vedio.winterHoliday.Person();
        int age=p.getAge();
        System.out.println(age);

    }


}
