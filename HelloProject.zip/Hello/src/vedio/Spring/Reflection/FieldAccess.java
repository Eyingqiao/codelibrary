package vedio.Spring.Reflection;

import vedio.winterHoliday.Person;

import java.io.File;
import java.lang.reflect.Field;

public class FieldAccess {
    public static void main(String[]args) throws ClassNotFoundException, NoSuchFieldException, IllegalAccessException, InstantiationException {
        //获取字节码文件
        String str="vedio.winterHoliday.Person";
        Class clazz=Class.forName(str);

        //获取字节码文件的字段
        Field field=null;//=clazz.getField("age");//xception in thread "main" java.lang.NoSuchFieldException: age
        field=clazz.getDeclaredField("age");//private int vedio.winterHoliday.Person.age

        //获取字节码文件对象，获取字段的值
       Object p=clazz.newInstance();//注意接受对象还是Object，不是person

//Exception in thread "main" java.lang.IllegalAccessException: class vedio.Spring.Reflection.
// FieldAccess cannot access a member of class vedio.winterHoliday.Person with modifiers "private"
        //对私有字段的访问取消权限检查，暴力访问，但是不推荐。

        /**
         *
         *
         * AccessibleObject 类是 Field、Method 和 Constructor 对象的基类。
         * 它提供了将反射的对象标记为在使用时取消默认 Java 语言访问控制检查的能力。
         * */

        field.setAccessible(true);//    将此对象的 accessible 标志设置为指示的布尔值
        field.set(p,30);//改变该字段的值

        Object object=field.get(p);


//        object=field.get(p);
        System.out.println(object);



    }
}
