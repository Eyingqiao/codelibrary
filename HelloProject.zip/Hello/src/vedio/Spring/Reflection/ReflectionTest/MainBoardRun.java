package vedio.Spring.Reflection.ReflectionTest;

public class MainBoardRun {
    public void run(){
        System.out.println("MainBoard Run");

    }

    public void UsePCI(PCI pci){
    pci.open();
    pci.close();


    }


}
