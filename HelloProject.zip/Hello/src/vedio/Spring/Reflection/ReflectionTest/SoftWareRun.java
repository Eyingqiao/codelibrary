package vedio.Spring.Reflection.ReflectionTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class SoftWareRun {

    public static void main(String[]args) throws IOException, ClassNotFoundException, IllegalAccessException, InstantiationException {

        MainBoardRun mainBoardRun=new MainBoardRun();
        mainBoardRun.run();

        //增加配置文件
        File file=new File("/home/ll/IdeaProjects/Hello/src/vedio/Spring/Reflection/ReflectionTest/conf.properties");

        Properties prop=new Properties();
        FileInputStream fileInputStream=new FileInputStream(file);
        //将文件内容加载至properties中
        prop.load(fileInputStream);
        //遍历所有PCI，只需要修改配置文件，就能增删PCI
        for(int i=1;i<=prop.size();i++){

            String className=prop.getProperty("pci"+i);

//
            Class cl=Class.forName(className);

            PCI pci=(PCI) cl.newInstance();
            mainBoardRun.UsePCI(pci);

        }


    }
}
