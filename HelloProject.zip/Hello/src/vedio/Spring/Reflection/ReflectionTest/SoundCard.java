package vedio.Spring.Reflection.ReflectionTest;

public class SoundCard implements PCI {


    @Override
    public void open() {
        System.out.println("SoudCard open");
    }

    @Override
    public void close() {
        System.out.println("SoundCard close");
    }
}
