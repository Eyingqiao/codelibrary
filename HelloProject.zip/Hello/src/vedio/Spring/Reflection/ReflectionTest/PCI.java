package vedio.Spring.Reflection.ReflectionTest;

interface  PCI {

    public void open();
    public void close();

}
