package vedio.Spring.Reflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.locks.Condition;

public class MethodRun {
    public static void main(String[]args) throws ClassNotFoundException, IllegalAccessException, NoSuchMethodException, InstantiationException, InvocationTargetException {


//        getMethod_1();




        getMethod_2();


    }

    private static void getMethod_2() throws ClassNotFoundException, IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {

        String str="vedio.winterHoliday.Person";
        Class cl=Class.forName(str);



//无参数函数的获取及运行
//        Object object=cl.newInstance();


//        Method method=cl.getMethod("show",null);
//        System.out.println(method);
//        method.invoke(object,null);


        //有参数的需要用构造器

          Object p=cl.newInstance();
        Method method=cl.getMethod("hahah", String.class, int.class);
        method.invoke(p,"lijian",29);







    }

    private static void getMethod_1() throws ClassNotFoundException {

        String str="vedio.winterHoliday.Person";
        Class cl=Class.forName(str);

//        Method[]methods=cl.getMethods();//所有共有方法，包括父类的。

        Method[]methods=cl.getDeclaredMethods();//该类自己的所有方法，包括私有的

        for(Method method:methods){


            System.out.println(method);

        }


    }
}
