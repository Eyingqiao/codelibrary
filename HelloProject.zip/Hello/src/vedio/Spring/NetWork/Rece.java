package vedio.Spring.NetWork;

import java.io.IOException;
import java.io.Reader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class Rece implements Runnable {

    private DatagramSocket dsR;
    public Rece(DatagramSocket dsR){
        this.dsR=dsR;

    }



    @Override
    public void run() {
        System.out.println("接收端接收数据");

        while(true) {
            byte[] bytes = new byte[1024];

            DatagramPacket dpR = new DatagramPacket(bytes, bytes.length);

            try {

                dsR.receive(dpR);
                String ip = dpR.getAddress().getHostAddress();
                bytes =dpR.getData();
                String str=new String(bytes,0, dpR.getLength());
                System.out.println(ip+"     "+str);

                if(str.equals("886")){
                    System.out.println("退出聊天室");
                    break;
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }
}
