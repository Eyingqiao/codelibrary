package vedio.Spring.NetWork;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class Send implements Runnable {


    private DatagramSocket ds;
    public Send(DatagramSocket ds){
            this.ds=ds;
    }

    @Override
    public void run() {
        System.out.println("发送数据");

        BufferedReader br3=new BufferedReader(new InputStreamReader(System.in));
        String str;

        try {
            while ((str=br3.readLine())!=null){

                byte[]bytes=str.getBytes();
                DatagramPacket dp3=new DatagramPacket(bytes,0,bytes.length, InetAddress.getByName("192.168.3.255"),10001);
                ds.send(dp3);
                if(str.equals("886")){
                    break;
                }


            }
//            ds.close();
        } catch (IOException e) {
                e.printStackTrace();
        }


    }






}


