package vedio.Spring.NetWork;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UDPSendDataBySocket1 {



    /**
     *
     * 数据来源属于键盘输入，并且以特定字符串结束发送
     *
     * */

    public static void main(String[] args) throws IOException {

        System.out.println("发送端开启");

        DatagramSocket ds = new DatagramSocket();//可以指定，否则系统指定，与接收方的的端口，不是一个


        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

        String str;
        while((str=br.readLine())!=null){


            byte[] bytes = str.getBytes();
            DatagramPacket dp = new DatagramPacket(bytes, bytes.length, InetAddress.getByName("192.168.3.144"), 10000);

            ds.send(dp);
            if(str.equals("886")){
                break;
            }

        }
        ds.close();






    }
}
