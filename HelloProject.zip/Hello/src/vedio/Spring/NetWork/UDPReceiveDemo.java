package vedio.Spring.NetWork;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class UDPReceiveDemo {



    /**
     *
     * 1-1024的端口不要用，有权限限制。
     *1建立Socket服务；
     * 2创建DategramPocket包，用以存储接收到的数据；
     * 3调用socket的receive方法，接收数据；
     * 4利用pocket对象的方法解析数据；
     * 5关闭socket；
     *
     * */
    public static void main(String[]args) throws IOException {
        System.out.println("接收端等待接收数据");
        DatagramSocket ds1=new DatagramSocket(10000);//必须指明接收的端口号（发送时标明了），否则接收不到。

        byte[]data=new byte[1024];

        DatagramPacket dp1=new DatagramPacket(data,data.length);

        ds1.receive(dp1);

       String ip= dp1.getAddress().getHostAddress();
       int port=dp1.getPort();
       data=dp1.getData();
        System.out.println(ip+" "+port+"    "+new String(data,0,dp1.getLength()));





    }
}
