package vedio.Spring.NetWork;

import java.io.IOException;
import java.net.*;

public class UDPSendDataBySocket {


    /**
     *
     * 1,建立socket服务
     * 2将要发送的数据封装成数据包
     * 3利用Socket发送
     * 4关闭Socket
     *
     *
     *
     * */

    public static void main(String[]args) throws IOException {

        System.out.println("发送端开启");

        DatagramSocket ds=new DatagramSocket(8000);//可以指定，否则系统指定，与接收方的的端口，不是一个

        String str="发送演示";
        byte[]bytes=str.getBytes();

        DatagramPacket dp=new DatagramPacket(bytes,bytes.length, InetAddress.getByName("192.168.2.194"),10000);

        ds.send(dp);
        ds.close();


    }
}
