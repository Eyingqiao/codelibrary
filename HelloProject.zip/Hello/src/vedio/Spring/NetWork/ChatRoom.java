package vedio.Spring.NetWork;

import java.net.DatagramSocket;
import java.net.SocketException;

public class ChatRoom {

    public static void main(String[]args) throws SocketException {

        DatagramSocket ds=new DatagramSocket();
        DatagramSocket dsR=new DatagramSocket(10001);//一定要特意指出，因为要从特定端口接收到自己信息。

//        Send send=new Send(ds);
//        Rece rece=new Rece(dsR);

        new Thread(new Send(ds)).start();

        new Thread(new Rece(dsR)).start();




    }


}
