package vedio.Spring.NetWork;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;


/**
 *
 *
 * 加了一个while循环，并且要将接收数据的socket扔在循环之外，否则端口被占用，冲突；
 * */
public class UDPReceiveDemo1 {



    public static void main(String[]args) throws IOException {
        System.out.println("接收端等待接收数据");
        DatagramSocket ds1 = new DatagramSocket(10000);
        while(true) {

           //必须指明接收的端口号（发送时标明了），否则接收不到。

            byte[] data = new byte[1024];

            DatagramPacket dp1 = new DatagramPacket(data, data.length);

            ds1.receive(dp1);

            String ip = dp1.getAddress().getHostAddress();
            int port = dp1.getPort();
            data = dp1.getData();
            System.out.println(ip + " " + port + "    " + new String(data, 0, dp1.getLength()));
        }




    }
}
