package vedio.Spring.NetWork;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class InetAddressDemo {//名字不要起的和类名字一样

    public static void main(String[]args) throws UnknownHostException {


        InetAddress ip;// InetAddress.getLocalHost();

        ip=InetAddress.getByName("10.22.67.44");
        System.out.println(ip.getHostAddress());
        System.out.println(ip.getHostName());


    }

}
