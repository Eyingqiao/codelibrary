function println(value){
    document.write(value+"</br>");

}

function print(value){
    document.write(value);

}
