function println(value) {
    document.write(value+"</br>");
}


Array.prototype.getMax=function () {
    var max=0;
    for(var i=0;i<this.length;i++){
        if(this[i]>this[max]){
            max=i;
        }
    }
    return this[max];


}

/**
 *
 * 引起递归
 * */
// Array.prototype.toString=function () {
//     println(this.toString());
// }