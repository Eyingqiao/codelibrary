
String.prototype.trim=function(){

    var len=this.length;
    var start=0,end=len-1;
    while ((start<=end)&&this.charAt(start)==' '){
        start++;

    }
    while(start<=end&&this.charAt(end)==' '){
        end--;
    }

    return this.substring(start,end+1);
}



String.prototype.toCharArray=function () {

    var arr=[];
    for (var i=0;i<this.length;i++){

        arr[i]=this.charAt(i);

    }

return arr;

}


String.prototype.reverse=function () {
    var arr=this.toCharArray();


    /**
     * 函数可以直接写在函数内部
     * */

    function swap(arr,a,b) {
        var temp=arr[a];
        arr[a]=arr[b];
        arr[b]=temp;

    }
    for(var j=0,k=this.length-1;j<k;j++,k--){
        swap(arr,j,k);
    }
    return arr.join();

}
