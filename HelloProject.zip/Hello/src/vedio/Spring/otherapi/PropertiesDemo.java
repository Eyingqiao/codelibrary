package vedio.Spring.otherapi;

import java.util.Properties;
import java.util.Set;

public class PropertiesDemo {

/**
 * otherapi.getProperties()返回值是键值对,系统的属性对;
 * 然后是使用接受键值对的(Properties)函数,得到set集合;
 *
 * 然后遍历,利用Properties的函数得到value.
 *
 * */

    public static  void main(String []args){


        Properties pr=System.getProperties();
//        String s=pr.getProperty("os.name");
//        otherapi.out.println(s);
        Set<String> ap=pr.stringPropertyNames();
        for(String key:ap){
            String value=pr.getProperty(key);
            System.out.println("key:    "+key+" value:   "+value);


        }

    }
}
