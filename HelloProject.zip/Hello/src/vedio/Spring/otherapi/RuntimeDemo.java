package vedio.Spring.otherapi;

import java.io.IOException;




public class RuntimeDemo {

/**单例设计模式;
 * destroy只能杀死Runtime开启的进程;
 *
 *
 * exec()里不知道应该填什么命令,哪怕格式对了,也没有输出显示.
 * */
    public static void main(String []args) throws InterruptedException {

        run();

    }
    public static void run() throws InterruptedException {

        Runtime r=Runtime.getRuntime();
        try {
            Process p=r.exec("ifconfig");
            Thread.sleep(1000);//
            p.destroy();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
