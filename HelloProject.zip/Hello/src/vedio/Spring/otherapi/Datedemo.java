package vedio.Spring.otherapi;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;




public class Datedemo {

    public static  void main(String[]args) throws ParseException {



        /**
         * 显示Date时间对象;
         * 将毫秒转成Date对象;
         *
         * */
//        long t=System.currentTimeMillis();
//
//        System.out.println(t);
//        Date da=new Date(3455666);
//        System.out.println(da);
//        long t1=da.getTime();
//        System.out.println(t1);
//
//       da.setTime(Long .MAX_VALUE);//括号内有字长限制,而不是值限制

//
//
//        System.out.println(da);

//        demo_1();
//        demo_2();

        Calendar calendar=Calendar.getInstance();
        calendar.set(2017,10,1);
        calendar.add(Calendar.MONTH,12);
        demo_3(calendar);



    }

    private static void demo_3(Calendar calendar) {
//        Calendar calendar=Calendar.getInstance();

        int year=calendar.get(Calendar.YEAR);
        int month=calendar.get(Calendar.MONTH)+1;//设置时间时,就不要加一了
        int day=calendar.get(Calendar.DAY_OF_MONTH);
        String week=getweek(calendar.get(Calendar.DAY_OF_WEEK));

        System.out.println(year+"年"+month+"月"+day+"日");
        System.out.println(week);


    }

    private static String getweek(int i) {
        String []wk={"","星期日","星期一","星期二","星期三","星期四","星期五","星期六"};//数字1-7,周日对应1
         return wk[i];


    }


    private static void demo_2() throws ParseException {
        /**
         * 比较两个日期字符串差多少时间
         * 1字符串转成Date对象;
         * 2Date对象转成毫秒;
         * 3毫秒加减;
         * 4值转成天数.
         *
         * */


        String str_1="2018-10-1.txt";
        String str_2="2019-1.txt-16";

        DateFormat dateFormat_1=DateFormat.getDateInstance();
        dateFormat_1=new SimpleDateFormat("yyyy-MM-dd");//如果显示 Unparseable date,就是格式不正确

        Date d1=dateFormat_1.parse(str_1);
        Date d2=dateFormat_1.parse(str_2);

        long t1=d1.getTime();
        long t2=d2.getTime();

        long dayN=t2-t1;

        System.out.println("the day between two dates is    "+(dayN/1000/60/60/24));






    }

    public  static  void demo_1(){

        /**
         * 获得日期格式对象,并指定风格,或者默认风格;
         *还可以使用SimpleDateFormat对象,自定义风格,即时间格式.
         *
         * */

        Date d=new Date();
        DateFormat dateFormat=DateFormat.getDateInstance(DateFormat.SHORT);//年月日

        dateFormat=DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.FULL);//加上时分秒

        dateFormat=new SimpleDateFormat("yyyy-MM-dd");
        String t=dateFormat.format(d);
        System.out.println(t);


    }
}
