package vedio.Spring.BrowserShowResult;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class TomcatServer_1 {


    /**
     *
     *
     *http://192.168.3.144:9090/
     * 用手机访问也可以
     * 但是无论是电脑还是手机都无法显示，连接时间，超时。
     * */

    public static void main(String[]args) throws IOException {


        ServerSocket serverSocket=new ServerSocket(9090);

        Socket socket=serverSocket.accept();

        //服务奇读取浏览器的内容
        BufferedReader in=new BufferedReader(new InputStreamReader(socket.getInputStream()));


//        PrintWriter printWriter=new PrintWriter(new OutputStreamWriter(System.out));
        String line;
        while ((line=in.readLine())!=null){
            System.out.println(line);

        }


        //要向浏览器发送信息
        OutputStream out=socket.getOutputStream();
        out.write("浏览器你好".getBytes());
        out.close();
        socket.close();
        serverSocket.close();





    }
}
