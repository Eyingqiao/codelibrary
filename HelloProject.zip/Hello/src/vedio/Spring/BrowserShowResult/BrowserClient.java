package vedio.Spring.BrowserShowResult;

import java.io.*;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URL;

public class BrowserClient {

/**
 *
 * 本来是为了访问Tomcat服务器的，然后尝试连接了一下自己写的服务器。
 *
 * */




    public static void main(String[]args) throws IOException {



        GetInputStream();
//        GetInputStream_1();//差点问题，可能是要求服务器端也要接收url






    }

    private static void GetInputStream_1() throws IOException {


        String str="http://192.168.2.194:9090/";

        URL url=new URL(str);

       InputStream in= url.openConnection().getInputStream();
        //等价于 url.openStream();



        byte[]bytes=new byte[1024];

        int len=in.read(bytes);
        System.out.println(new String(bytes,0,len));

        in.close();
//        url./


    }

    private static void GetInputStream() throws IOException {

        Socket socket=new Socket("192.168.2.194",9090);

//        OutputStream outputStream=socket.getOutputStream();
        PrintWriter printWriter=new PrintWriter(socket.getOutputStream(),true);

        printWriter.println("GET HTTP/1.1");
        printWriter.println("Accept:*/*");
        printWriter.println("Host: 192.168.3.144:9090");
        printWriter.println("Connection:close");
        printWriter.println();
        printWriter.println();

        socket.shutdownOutput();
        InputStream in=socket.getInputStream();

        byte[]bytes=new byte[1024];
        int len=in.read(bytes);
        System.out.println(new String(bytes,0,len));

        socket.close();





    }

}
