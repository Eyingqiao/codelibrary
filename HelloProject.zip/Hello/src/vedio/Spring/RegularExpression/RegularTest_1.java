package vedio.Spring.RegularExpression;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularTest_1 {


    /**
     *
     * 网络爬虫，爬取网页信息，从某个网页中选择能匹配你需求（正则表达式）的信息
     *（以邮件为例）
     * 1 源：URL/文件/或者页面等
     * 2 判断匹配
     * 3 存取数据
     *
     *
     * */


    public static void main(String[]args) throws IOException {


       List<String> ll= SelectYouWant();
        for (String str:ll){

            System.out.println(str);
        }


    }

    private static List<String> SelectYouWant() throws IOException {

        URL url=new URL("http://www.baidu.com:80");
//        url.openConnection()

        BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(url.openStream()));


//        String argx="\\w+@+\\w+(\\.+\\w)+";
        String argx="\\b\\w{1,3}";
        //随意改的，因为好像没有邮箱信息，我也不知道80端口对应什么页面，进不去，用此字段反返回了DOC STA的结果


        String line=null;

        Pattern pattern=Pattern.compile(argx);

        List<String>list=new ArrayList<>();


        while((line=bufferedReader.readLine())!=null){
            Matcher m=pattern.matcher(line);

            if(m.find()){

                list.add(m.group());
            }

        }


        return list;
    }


}
