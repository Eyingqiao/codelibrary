package vedio.Spring.RegularExpression;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Regular {



    public static void main(String[]args) {




//        IfNumber();//判断是否是一串数字

//        test_QQ();//matches

//        test_PhonNumber();//matches
//        test_split();//split
//        test_replace();

//        test_GetMatchered();
         }

    private static void IfNumber() {
        try {
            String ss = "111o";
            long re = Long.parseLong(ss);
            System.out.println(re);


        } catch (NumberFormatException ne) {
            System.out.println("NumberFormatException");
        }

    }

    private static void test_GetMatchered() {
        String str="jfsk kjf sdka sd kj dask js";
        String argx="\\b[a-z]{3}\\b";//加边界，剔除大于三个的字符串


        Pattern pattern=Pattern.compile(argx);
        Matcher m=pattern.matcher(str);

//        boolean result= m.find();//boolean  尝试查找与该模式匹配的输入序列的下一个子序列。
        while (m.find()) {
            System.out.println(m.group());//返回匹配的字符串
            System.out.println(m.start()+":"+m.end());//字符串序列在原是字符串中的索引
        }


    }


    private static void test_replace() {
        String str="zhangsanuuulijsillllwangaiguo";

        String rap=str.replaceAll("(.)\\1+","$1");
        System.out.println(rap);

        String number="15888399320";
        String secretNumber=number.replaceAll("(\\d{3})\\d{4}(\\d{4})","$1****$2");
        System.out.println(secretNumber);



    }

    private static void test_split() {

        String splitNames="zhangsanttttlijianyyyywangwu";

        String[]names=splitNames.split("(.)\\1");
        for(String name:names){
            System.out.println(name);
        }



    }

    private static void test_PhonNumber() {
        String pnum="15899896666";
        String arx="1[358]\\d{9}";//加转义字符

        boolean r1=pnum.matches(arx);
        System.out.println(pnum+"   "+r1);



    }

    private static void test_QQ() {


        String qq="1191";
        String argx="[1-9][0-9]{4,14}";
        boolean result=qq.matches(argx);

        System.out.println(qq+" "+result);
    }


}
