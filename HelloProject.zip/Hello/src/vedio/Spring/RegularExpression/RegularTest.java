package vedio.Spring.RegularExpression;

import java.util.TreeSet;

public class RegularTest {

    /**
     *
     * 1治疗口吃：我我我。。。要要要要要。。。。。要要要要。。吃吃吃吃吃吃......芒芒芒芒芒....芒芒芒...果果果果果
     *
     * 2 ip排序： 192.54.6.6 103.44.5.5 3.10.4.33
     * */

    public static void main(String []args){


//        test_1();
        test_2();



    }

    private static void test_2() {

        String ips="192.54.6.6 103.44.5.5    3.10.4.33  192.21.2.12";

        //先切空格；
        String[]ipp=ips.split("\\s+");


        TreeSet<String> ts=new TreeSet<>();


        for(String ip:ipp){
//            System.out.println(ip);
            //默认按照字符串比较，但是要调整成按字段比较，加0填充。
            String ip1=ip.replaceAll("(\\d+)","00$1");

            //加完零，要再切回去，保持每段三位

            String ip2=ip1.replaceAll("0*(\\d{3})","$1");


            ts.add(ip2);


        }
        //最后还是要切掉多余的0

        for(String tt:ts){

            String fi=tt.replaceAll("0*(\\d+)","$1");
            System.out.println(fi);
        }
//
//        System.out.println(ts.toString());











    }

    private static void test_1() {

        String str1="我我我......要要要要要......要要要要......吃吃吃吃吃吃......芒芒芒芒芒....芒芒芒...果果果果果";
        String r1=str1.replaceAll("\\.","");
//        System.out.println(r1);
        String r2=r1.replaceAll("(.)\\1+","$1");
        System.out.println(r2);



    }


}
