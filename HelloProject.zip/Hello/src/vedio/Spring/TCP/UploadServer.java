package vedio.Spring.TCP;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class UploadServer {





    public static void main(String[]argas) throws IOException {

        ServerSocket serverSocket=new ServerSocket(10004);

        Socket socket=serverSocket.accept();

        BufferedReader in=new BufferedReader(new InputStreamReader(socket.getInputStream()));


        BufferedWriter bufferedWriter=new BufferedWriter(new FileWriter("//home/ll/IdeaProjects/Hello/src/vedio/Spring/TCP/server.txt"));


        String line;
        while((line=in.readLine())!=null){
            bufferedWriter.write(line);


            /**
             *
             *如果不读一行刷新一次会导致，装满缓冲区后的剩余字节被丢弃，不被写入
             * 缓冲区的大小是有限制的，毕向东的视频上说是8K，但是我试验之后，应该12KB的文件，得到11.5KB，但是有可能是写成了一行没有回车的原因，
             * 所以研究文件真的很麻烦。
             * 要记住用缓冲区写的时候，一写一换行，一写一刷新。
             *而且为了避免等待，客户端往socket网络流中输出（写）时，
             * 要让等待在另一边的服务器端知道你已经写完了，他才算读完，不要一直等待。socket。shutdownOutput（）；
             *
             * */
            bufferedWriter.newLine();
            bufferedWriter.flush();

        }


//求求你，用PrintWriter的时候一定要加true，自动刷新！！！！！！！
        PrintWriter out=new PrintWriter(new OutputStreamWriter(socket.getOutputStream()),true);

        out.println("传输完毕");

        bufferedWriter.close();

        socket.close();
        serverSocket.close();




    }



}
