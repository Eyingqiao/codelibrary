package vedio.Spring.TCP;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class TCPServer1 {


    /**
     * 需求：通过客户端对象获取socket流，读取客户端发来的数据
     *
     *
     * 1创建服务器端socket服务
     * 2服务器必须对外提供一个接口，否则服务器无法连接
     * 3获取连接过来的客户端对象
     * 4通过客户端获取socket流，读取客户端发来的的数据
     * 5关闭资源：主要是在服务器端关闭客户端，因为客户端不可控
     *
     * */

    public static void main(String []args) throws IOException {

        /**
         *
         * 给客户端回信
         * */
        ServerSocket serverSocket1=new ServerSocket(10002);

        Socket socket=serverSocket1.accept();

        InputStream inputStream=socket.getInputStream();

        byte[]bytes=new byte[1024];

        int len=inputStream.read(bytes);


        String ip=socket.getInetAddress().getHostAddress();

        System.out.println(ip);//客户端的地址

        System.out.println(new String(bytes,0,len));



        //给客户端回信
        OutputStream outputStream=socket.getOutputStream();

        outputStream.write("给客户端回信".getBytes());



        socket.close();
//        serverSocket.close();




    }

}
