package vedio.Spring.TCP;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

/**
 * 1用sockt对象创建客户端Socket服务
 * 2如果连接建立成功，数据通道也建立起来
 *      有了网络流，可以利用socket的函数获取输入输出流
 * 3使用输出流，将数据写出
 * 4关闭资源，只关闭socket资源即可
 *
 * */

public class TCPClientOutput1 {
    /**
     *
     *
     * 增加功能：读取服务器的回信
     *
     * */

    public static void main(String[]args) throws IOException {

        Socket socket=new Socket("192.168.3.144",10002);

        OutputStream outputStream=socket.getOutputStream();

        outputStream.write("TCP输出流获取成功".getBytes());



        //读取回信

        InputStream in=socket.getInputStream();

        byte[]bytes=new byte[1024];

        int len=in.read(bytes);

        System.out.println(new String(bytes,0,len));




        socket.close();


    }

}
