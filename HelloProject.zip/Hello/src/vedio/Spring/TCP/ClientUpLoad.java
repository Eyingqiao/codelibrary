package vedio.Spring.TCP;

import java.io.*;
import java.net.Socket;

public class ClientUpLoad implements Runnable {

    private  Socket socket;
    public ClientUpLoad(Socket socket) {

        this.socket=socket;
    }

    @Override
    public void run() {

        int count=0;
        try {
            InputStream in = socket.getInputStream();

            File dir = new File("/home/ll/IdeaProjects/Hello/src/vedio/Spring/TCP");
            String ip = socket.getInetAddress().getHostAddress();


            File f=new File(dir,ip+".jpg");


            while(f.exists()){
                          f=new File(dir,ip+(count++)+".jpg");

                     }
            FileOutputStream fileOutputStream = new FileOutputStream(f);

            byte[] bytes = new byte[1024];
            int len;
            while ((len = in.read(bytes)) != -1) {

                fileOutputStream.write(bytes, 0, len);

            }

            OutputStream out = socket.getOutputStream();
            out.write("复制成功".getBytes());
//        serverSocket.close();
            socket.close();
            fileOutputStream.close();
        }catch(IOException e){
            System.out.println(e);

        }

    }
}
