package vedio.Spring.TCP;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class UploadPictureServer {
    public static void main(String[]args) throws IOException {


        ServerSocket serverSocket=new ServerSocket(10005);
        Socket socket=serverSocket.accept();
        InputStream in=  socket.getInputStream();

        File dir=new File("/home/ll/IdeaProjects/Hello/src/vedio/Spring/TCP");
        String ip=socket.getInetAddress().getHostAddress();
        FileOutputStream fileOutputStream=new FileOutputStream(new File(dir,ip+".jpg"));

        byte[]bytes=new byte[1024];
        int len;
        while ((len=in.read(bytes))!=-1){

            fileOutputStream.write(bytes,0,len);

        }

        OutputStream out=socket.getOutputStream();
        out.write("复制成功".getBytes());

        serverSocket.close();
        socket.close();
        fileOutputStream.close();




    }
}
