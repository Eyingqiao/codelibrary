package vedio.Spring.TCP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;



/**
 *
 * 需求:客户端发送给客户端的数据，要求服务器能够以大写返回
 *
 * 1创Socket对象，建立连接
 * 2读取键盘录入
 * 3发送到服务器
 *
 *
 * */
public class ToUpperCaseClient {


    public static void main(String[]args) throws IOException {


        Socket socket=new Socket("192.168.3.144",10004);
//获取键盘输入
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

        //获取socket，输出流，读一行，写一行
        //获得原样输出，而且自动刷新
        PrintWriter out=new PrintWriter(socket.getOutputStream(),true);




        BufferedReader in=new BufferedReader(new InputStreamReader(socket.getInputStream()));

        int len;
        String str;
        while ((str=br.readLine())!=null){
            //从键盘读出一行，写入输出流一行
                out.println(str);//特有方法
            //写入一行，从服务器中获取一行，打印
//            byte[]bytes=new byte[1024];
            String Upper;

            Upper =in.readLine();

            System.out.println(Upper);

        }





    }

}
