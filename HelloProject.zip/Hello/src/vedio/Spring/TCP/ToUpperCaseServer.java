package vedio.Spring.TCP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ToUpperCaseServer {
    /**
     *
     *
     * 1获取Serversocket对象
     * 2获取socket对象
     * 3获取流控制台输出
     * 4换大写，写回去
     * 5关闭资源
     *
     * */

    public static void main(String[]aeg) throws IOException {


        ServerSocket serverSocket=new ServerSocket(10004);
//获取socket对象
        Socket socket=serverSocket.accept();


        BufferedReader br=new BufferedReader(new InputStreamReader(socket.getInputStream()));

        //写回
        PrintWriter out=new PrintWriter(socket.getOutputStream(),true);//一定不要忘了“true

       String str;

        while((str=br.readLine())!=null){
            System.out.println(str);

            out.println(str.toUpperCase());



        }
        socket.close();
        serverSocket.close();








    }






}
