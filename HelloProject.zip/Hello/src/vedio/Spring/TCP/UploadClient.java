package vedio.Spring.TCP;


import java.io.*;
import java.net.Socket;

/**
 *
 *
 * 需求：客户端从文件中读取数据，然后发送到服务器端
 *      服务器读完，要给客户端反馈
 *
 *  1
 *  建立客户端socket服务
 *  2 读文件
 *  3往输出流写
 *  4等待读输入流（来自服务器的反馈），将其输出
 *  5关闭文件流
 *
 * */

public class UploadClient {


    public static void main(String []agrs) throws IOException {
        Socket socket=new Socket("192.168.2.194",10004);

//        BufferedInputStream bufferedReader=new BufferedInputStream("client.txt");
        BufferedReader bufferedReader=new BufferedReader(new FileReader("//home/ll/IdeaProjects/Hello/src/vedio/Spring/TCP/client"));


        PrintWriter out=new PrintWriter(socket.getOutputStream(),true);


        String line;
        while ((line=bufferedReader.readLine())!=null){

            out.println(line);

        }

        socket.shutdownOutput();

        BufferedReader in= new BufferedReader(new InputStreamReader(socket.getInputStream()));

        String reply=in.readLine();
        System.out.println(reply);

//        socket.close();
        bufferedReader.close();
        socket.close();








    }


}
