package vedio.Spring.TCP;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.TreeSet;




/**
 *
 * 防止多客户端阻塞上传，实现并发上传，运用多线程技术
 * 当sockt出现时，封装成线程，并将操作封装
 *
 * */
public class UploadPictureServerMutilateClients {
    public static void main(String[]args) throws IOException {


        ServerSocket serverSocket=new ServerSocket(10005);


        while(true){

            Socket socket=serverSocket.accept();
            new Thread(new ClientUpLoad(socket)).start();


        }









    }
}
