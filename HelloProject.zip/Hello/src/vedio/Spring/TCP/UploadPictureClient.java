package vedio.Spring.TCP;

import java.io.*;
import java.net.Socket;

public class UploadPictureClient {



    /**
     *
     * 图片用字节流写，一定要纯粹？
     *
     * */
    public static void main(String[]args) throws IOException {
        Socket socket=new Socket("192.168.3.144",10005);

        FileInputStream inputStream=new FileInputStream("/home/ll/IdeaProjects/Hello/src/vedio/Spring/TCP/1.jpg");

        OutputStream out=socket.getOutputStream();

        byte[]bytes=new byte[1024];
        int len;
        while ((len=inputStream.read(bytes))!=-1){

            out.write(bytes,0,len);


        }

        socket.shutdownOutput();
       BufferedReader in=new BufferedReader(new InputStreamReader(socket.getInputStream()));
//        InputStream inputStream1=socket.getInputStream();
        String str=in.readLine();
        System.out.println(str);

        socket.close();
//        out.close();

        inputStream.close();





    }
}
