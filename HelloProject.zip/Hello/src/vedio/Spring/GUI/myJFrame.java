package vedio.Spring.GUI;

public class myJFrame {
}
