package vedio.Spring.GUI.Component;

import java.awt.*;
import java.awt.event.*;
//import java.io.File;



/**
 *
 *
 *
 * consume()textField組件默認註冊了keylistener,當textField為當前focus組件時,keyEvent默認情況下會按照該事件產生一個按鍵動作,生成一個keycode,顯示在textField裡面,這是組件的默認行為.
 * 若consume此事件,textField裡面將不會顯示此字符...
 * */
public class MouseListenerDemo {


    private Frame f;

    private TextField tf;
    private Button b;


    MouseListenerDemo(){
        Init();
    }

    public void Init() {

        f=new Frame("鼠标监听");
        f.setLayout(new FlowLayout());
        f.setBounds(100,200,300,400);

        //加按钮和文本框到窗体；
        tf=new TextField(100);
         b=new Button("一个按钮");
        f.add(b);
        f.add(tf);



        event();

    f.setVisible(true);


    }

    private void event() {
        //为事件源绑定监听器


        //为窗体增加关闭按钮（windows的监听器）

        f.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                System.exit(0);
            }
        });

        //为按钮增加活动监听器（button的监听器）
//        b.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                System.out.println("活动监听器");
//            }
//        });

        //为按钮增加鼠标的监听器，Component都有的
        b.addMouseListener(new MouseAdapter() {
           private  int count=0;
//            @Override
//            public void mouseEntered(MouseEvent e) {
//                super.mouseEntered(e);
//                System.out.println("进入" );
//            }

            @Override
            public void mousePressed(MouseEvent e) {
                super.mousePressed(e);
                //设置成双击时才触发
                if(e.getClickCount()==2){

                    //将内容打印到文本框中
//                    tf.setText(e.toString()+(count));//
                    count++;

                }

            }
        });





        //为文本框添加键盘监听
        tf.addKeyListener(new KeyAdapter() {

            @Override
            public void keyPressed(KeyEvent e) {

//				System.out.println("key run..."+KeyEvent.getKeyText(e.getKeyCode())+"::::"+e.getKeyCode());
				int code = e.getKeyCode();
				if(!(code>=KeyEvent.VK_0 && code<=KeyEvent.VK_9)){
					System.out.println("必须是数字");
					e.consume();//方法用不了不知道为神魔
				}
                if(e.isControlDown()&&(e.getKeyCode()==KeyEvent.VK_ENTER)){
                    System.out.println("crtl down +enter");
                }


            }
        });









    }

    public static void main(String[]args){

        new MouseListenerDemo();

    }


}
