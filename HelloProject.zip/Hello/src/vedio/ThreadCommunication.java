package vedio;
/**
 * 等待唤醒机制
 * 优化后的代码，将方法也扔到了资源里面直接调用就可以
 *函数的所是this 本身
 *
 * lock本身是cpu的执行权，如果一个线程冻结进入等待，执行权被剥夺，交给其他线程执行；所以多线程，同syn 同步set 时，不会限制期间年入set
 * 如果没有同步的限制，语句块（方法)没有被封装，各个线程随即执行各条语句，就会出现不同步，也就是这个数据其实已经改变了，但是却都城原来的数据。
 * 使用同步能实现同一时间只有一个线程能操作数据。
 *
 * 该版本是多消费者多生产者的同步解决方案最出版，只能全部唤醒，不然用while(flag)会死所，只能呢个互相notifyAll;
 * */

class Resource{

    public String name;
    public String sex;
    boolean flag=false;
    private int count=0;
    int x=0;
    public synchronized void set() {

        while (flag) {
            try{this.wait();}//关键指出，要指定监视器，也就是对象，也就是所
            catch(InterruptedException e){}
        }
            if (x == 0) {

                this.name = "玛丽";
                this.sex = "女";
            } else {

                this.name = "mike";
                this.sex = "man";

            }
            count++;
            x = (x + 1) % 2;
            System.out.println(Thread.currentThread().getName()+"       "+"in"+"            "+count);
            flag = true;
            this.notifyAll();


    }


    public synchronized void get(){

        while(!flag){
            try{this.wait();}catch(InterruptedException e){ }
        }
        System.out.println(Thread.currentThread().getName()+"       "+name + "     " + sex+"        "+count);
        flag=false;
        this.notifyAll();

    }



}






class Input implements Runnable{
    Resource r=new Resource();
//    int x=0;
    Input(Resource r){
       this.r=r;

    }



    @Override
    public void run() {
        while(true) {
//            synchronized (r) {
//                if (r.flag){
//
//                    try{r.wait();}catch(InterruptedException e){
////                        otherapi.out.println(Thread.getAllStackTraces());
//
//                    }
//                }
//
//            }

//            otherapi.out.println(Thread.currentThread().getName()+"           in  ");
            r.set();


        }
//        otherapi.out.println(r.name+"     "+r.sex);


    }
}


class Output implements Runnable{

    Resource r=new Resource();

    Output(Resource r){
        this.r=r;

    }


    @Override

    public void run() {
        while(true) {
//            synchronized (r) {
//                if(!r.flag){
//                    try{r.wait();}catch(InterruptedException e){ }
//                }
//                otherapi.out.println(r.name + "     " + r.sex);
//                r.flag=false;
//                r.notify();
//            }


//            otherapi.out.println(Thread.currentThread().getName()+"           out  ");

            r.get();
        }

    }
}





public class ThreadCommunication {

    public static  void main(String [] args){
        Resource r=new Resource();
        Input in =new Input(r);
        Output out =new Output(r);

        Thread it=new Thread(in);
        Thread it1=new Thread(in);//后来家的，变成多消费者多生产这；

        Thread ot=new Thread(out);
        Thread ot1=new Thread(out);//后来家的，变成多消费者多生产这；
        it.start();
        ot.start();
        it1.start();//后来家的，变成多消费者多生产这；
        ot1.start();//后来家的，变成多消费者多生产这；






    }




}
