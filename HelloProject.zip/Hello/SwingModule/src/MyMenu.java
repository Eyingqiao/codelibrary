import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

public class MyMenu {

    private JPanel Panel;
    private JToolBar ToolBar;
    private JButton button1;
    private JTextArea textArea1;
    private JButton 保存Button;
//    private JDialog dialog;

    private JFileChooser chooser;

    private static final String LINE_SEPARATOR = System.getProperty("line.separator");
    public MyMenu() {
        button1.addActionListener(new ActionListener() {


            @Override
            public void actionPerformed(ActionEvent e) {
//                dialog=new JDialog();
//                dialog.setVisible(true);

//代码来源于javax.swing的JFilechooser的示例；

                chooser= new JFileChooser();

                int returnVal=chooser.showOpenDialog(chooser);
                if(returnVal==JFileChooser.CANCEL_OPTION){
                    System.out.println("取消选取文件");
                    return;
                }

                File f=chooser.getSelectedFile();

                try {
                    BufferedReader br=new BufferedReader(new FileReader(f));
                    String line;
                    try {
                        while((line=br.readLine())!=null){

                            textArea1.append(line+LINE_SEPARATOR);//打开其实是乱码的

                        }
                        br.close();

                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }


                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                }


            }
        });
        保存Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                chooser=new JFileChooser();
                int returnVal1=chooser.showOpenDialog(chooser);
                if(returnVal1==JFileChooser.CANCEL_OPTION){
                    System.out.println("取消选取文件");
                    return;
                }
                File fStore=chooser.getSelectedFile();

                String text=textArea1.getText();
                try {
                    BufferedWriter bw=new BufferedWriter(new FileWriter(fStore));
                    bw.write(text);
                    bw.close();


                } catch (IOException e1) {
                    e1.printStackTrace();
                }


            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("MyMenu");
        frame.setContentPane(new MyMenu().Panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

    }
}
