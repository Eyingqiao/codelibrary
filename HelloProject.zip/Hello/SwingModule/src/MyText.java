import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;


/**
 *
 * 在输出的基础上，在下面文本区域之前加了一个scrollpanel，在内容多时，可以滚动，全部显示。
 * 虽然我加完之后并没有在代码中发现scrollpanel
 *
 *
 * */


public class MyText {
    private JTextField textField1;
    private JButton Button;
    private JTextArea textArea1;
    private JPanel Panel;
    private static final String LINE_SEPARATOR = System.getProperty("line.separator");




    public void showDir() {


        String str_text=textField1.getText();//出错一次
//                System.out.println("show data");
        System.out.println(str_text);


        File f=new File(str_text);//出错1次
        if(f.exists()&&f.isDirectory()){
            textArea1.setText("");

            String str[]=f.list();

            for(String name:str){
//                       if(file)
//                        System.out.println(name);
                textArea1.append(name+LINE_SEPARATOR);

            }



        }
    }


    public MyText() {



        Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                showDir();

            }

        });
        textField1.addKeyListener(new KeyAdapter() {//为文本框添加键盘监听器，和按下按钮一样使目录显示
            @Override
            public void keyPressed(KeyEvent e) {
                super.keyPressed(e);

                if(e.getKeyCode()==KeyEvent.VK_ENTER){

                    showDir();
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("MyText");
        frame.setContentPane(new MyText().Panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
//        new MyText();

    }

}
