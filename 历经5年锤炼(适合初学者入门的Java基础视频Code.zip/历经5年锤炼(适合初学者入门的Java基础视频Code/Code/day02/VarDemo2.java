class VarDemo2
{
	public static void main(String[] args) 
	{

//		int x = 3;
//		byte b = 5;
//		x  = x + b;

//		byte b = 3;
//		b = (byte)(b + 200);//ǿ������ת����

		

		//System.out.println((char)('a'+1));
//		System.out.println('��'+0);//unicode���ʱ�׼�����


		byte b = 4;
		//b = 3+7;
		byte b1 = 3;
		byte b2 = 7;

		//b2 = 127;
		int x;
		//b = b1 + b2;
		int x1 =Integer.MAX_VALUE ;
		int x2 =2;
		x = x1+x2;

		//System.out.println(x);



		int n = 8;
		n = 9;
		n = 19;

		//System.out.println(n);


	
	}
}
