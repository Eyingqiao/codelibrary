class VarDemo 
{
	public static void main(String[] args) 
	{
		//��������    ������  =  ��ʼ��ֵ;
			byte	b = 3;
			short s = 4000;
			int x = 12;
			long l = 123l;

			float f = 2.3f;

			double d = 3.4;

			char ch = '1';

			boolean bl = true;
			bl = false;
			
		{
			int z = 9;
			System.out.println(z);
		}
			
		System.out.println(z);

		//System.out.println(y);
	}
}
