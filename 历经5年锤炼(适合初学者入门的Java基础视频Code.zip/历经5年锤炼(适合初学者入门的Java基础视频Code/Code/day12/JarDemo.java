package pack;

/*

Jar:java��ѹ������



*/

class JarDemo 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello Jar!");
	}
}
//./pack
//./haha.jar/pack