
package packa;

public  class  DemoA extends packb.DemoB
{
	public void show()
	{
		method();
		System.out.println("demoa show run");
	}
}
