package cn.itcast.reflect.test;

public interface PCI {
	
	public void open();
	public void close();

}
