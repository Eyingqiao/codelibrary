/**
 * @author Administrator
 */

alert("hello javascript 22");

